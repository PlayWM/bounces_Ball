import os
import sys
import time
import math
import statistics
import datetime
import gc
import random
import platform
import threading
import urllib.request
import urllib.parse
import json
import csv
import io
import re
import base64
import ssl
import ctypes
from ctypes import wintypes
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk, filedialog, messagebox
from tkinterdnd2 import TkinterDnD, DND_FILES
import win32com.client as win32
import win32timezone
import pythoncom
import openpyxl
from openpyxl.utils import get_column_letter

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

# ==========================================
# [버전 및 원격 설정 관리]
# ==========================================
APP_VERSION = "v260929.02"

def _decode_str(b64_str):
    try:
        return base64.b64decode(b64_str.encode("utf-8")).decode("utf-8").strip()
    except Exception:
        return ""

_ENC_CONFIG = "aHR0cHM6Ly9kb2NzLmdvb2dsZS5jb20vc3ByZWFkc2hlZXRzL2QvZS8yUEFDWC0xdlJpRk82NVo2blo1TFdjcmVJRGtiR2RKQU9SMWVjdlFJTUkyMVZqTkM2NW9fWmpkaS12M0pxVTd5OFVXR1ptSnpMNlhpVThwQ1lCVW8tcS9wdWI/Z2lkPTgyMjg4OTc0NyZzaW5nbGU9dHJ1ZSZvdXRwdXQ9Y3N2"
_ENC_FORM = "aHR0cHM6Ly9kb2NzLmdvb2dsZS5jb20vZm9ybXMvZC9lLzFGQUlwUUxTZGhOSTM3d2lVdGp0U0ZtR2ZqNjJ4T3NiYXE3WUJWZGtSZzZRRTR6TVNsUlhXdTRnL2Zvcm1SZXNwb25zZQ=="

TG_BOT_TOKEN = "8628791620:AAHzMQSZ8oDxU3xzp6ZBnpaahe_cEmQR3uc"
TG_CHAT_ID = "8855543969"

CONFIG_CSV_URL = _decode_str(_ENC_CONFIG)
FORM_URL = _decode_str(_ENC_FORM)

ENTRY_USER = "entry.1021532302"
ENTRY_ACTION = "entry.1811919804"
ENTRY_FILE = "entry.899483808"

_cached_geo_str = None
_user_alias_map = {}

MEASURE_NAME_MAP = {
    "두께": "Độ dày", "외경": "Đường kính ngoài", "내경": "Đường kính trong",
    "전장": "Chiều dài tổng", "길이": "Chiều dài", "높이": "Chiều cao",
    "폭": "Chiều rộng", "너비": "Chiều rộng", "깊이": "Độ sâu",
    "평면도": "Độ phẳng", "동축도": "Độ đồng trục", "진원도": "Độ tròn",
    "직각도": "Độ vuông góc", "평행도": "Độ song song", "단차": "Bậc chênh",
    "간격": "Khoảng cách", "피치": "Bước (Pitch)", "홀": "Lỗ",
    "거리": "Khoảng cách", "각도": "Góc độ", "외측": "Bên ngoài", "내측": "Bên trong"
}

def translate_measure_name(name, lang):
    if lang == "ko":
        return name
    res = name
    for k, v in MEASURE_NAME_MAP.items():
        res = re.sub(rf"\b{k}\b", v, res, flags=re.IGNORECASE)
        res = res.replace(k, v)
    return res

def parse_version_tuple(v_str):
    nums = re.findall(r"\d+", str(v_str))
    return tuple(map(int, nums)) if nums else (0,)

def get_client_identifiers():
    try:
        user_name = os.getlogin().strip()
    except Exception:
        user_name = "Unknown_User"
    pc_name = platform.node().strip()
    return user_name, pc_name

def _clean_token(text):
    return re.sub(r"[^A-Z0-9]", "", str(text).upper())

def get_resolved_user_name():
    """Config 시트 A열(PC명/계정명)과 매핑하여 B열 실명만 추출"""
    user_name, pc_name = get_client_identifiers()
    clean_u = _clean_token(user_name)
    clean_p = _clean_token(pc_name)

    # 1. 완전 일치 또는 서브 토큰 매칭
    for raw_k, name_val in _user_alias_map.items():
        clean_k = _clean_token(raw_k)
        if not clean_k:
            continue
        # clean_k 안에 계정명이나 PC명이 들어있거나 반대인 경우 전부 매칭
        if (clean_u and clean_u in clean_k) or (clean_p and clean_p in clean_k):
            return name_val
        if (clean_k in clean_u) or (clean_k in clean_p):
            return name_val

    return f"{user_name} ({pc_name})"

def get_client_geo():
    """위도/경도를 완전히 제외한 도시/국가 위치만 반환"""
    global _cached_geo_str
    if _cached_geo_str:
        return _cached_geo_str

    try:
        req = urllib.request.Request("http://ip-api.com/json/", headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=2.5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("status") == "success":
                city = data.get('city', '').strip()
                country = data.get('country', '').strip()
                if city and country:
                    _cached_geo_str = f"{city}, {country}"
                else:
                    _cached_geo_str = city or country or "위치불명"
            else:
                _cached_geo_str = "위치불명"
    except Exception:
        _cached_geo_str = "위치불명"

    return _cached_geo_str

def get_client_id_for_forms():
    """구글 시트 수식 호환용"""
    user_name, pc_name = get_client_identifiers()
    resolved = get_resolved_user_name()
    geo = get_client_geo()
    return f"{resolved} ({pc_name}) | {geo}"

def _send_tg_direct(action, resolved_user, geo_location, file_info):
    try:
        if "실행" in action:
            icon_tag = "🚨 [프로그램 실행]"
        elif "분석" in action:
            icon_tag = "🔍 [자료 분석]"
        elif "저장" in action or "작성" in action:
            icon_tag = "💾 [파일저장]"
        else:
            icon_tag = f"🔔 [{action}]"

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        lines = [
            f"{icon_tag}",
            f"• 시각: {now_str}",
            f"• 사용자: {resolved_user}",
            f"• 접속지역: {geo_location}"
        ]
        
        if "실행" not in action and file_info and file_info != "없음":
            lines.append(f"• 대상파일: {file_info}")

        text = "\n".join(lines)

        api_url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage"
        post_data = urllib.parse.urlencode({
            "chat_id": TG_CHAT_ID,
            "text": text
        }).encode("utf-8")

        ssl_ctx = ssl.create_default_context()
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE

        req = urllib.request.Request(
            api_url,
            data=post_data,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Content-Type": "application/x-www-form-urlencoded"
            }
        )
        with urllib.request.urlopen(req, timeout=5.0, context=ssl_ctx):
            pass
    except Exception:
        pass

def _send_payload(payload, action, file_info, resolved_user, geo_location):
    try:
        data = urllib.parse.urlencode(payload).encode("utf-8")
        req = urllib.request.Request(FORM_URL, data=data, headers={"User-Agent": "Mozilla/5.0"})
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass
    
    _send_tg_direct(action, resolved_user, geo_location, file_info)

def send_telemetry(action, file_info=""):
    def _worker():
        resolved_user = get_resolved_user_name()
        geo_location = get_client_geo()
        payload = {
            ENTRY_USER: get_client_id_for_forms(),
            ENTRY_ACTION: action,
            ENTRY_FILE: file_info
        }
        _send_payload(payload, action, file_info, resolved_user, geo_location)

    threading.Thread(target=_worker, daemon=True).start()

def send_telemetry_sync(action, file_info=""):
    resolved_user = get_resolved_user_name()
    geo_location = get_client_geo()
    payload = {
        ENTRY_USER: get_client_id_for_forms(),
        ENTRY_ACTION: action,
        ENTRY_FILE: file_info
    }
    _send_payload(payload, action, file_info, resolved_user, geo_location)

def verify_remote_license():
    global _user_alias_map
    try:
        nocache_url = f"{CONFIG_CSV_URL}&_nocache={int(time.time() * 1000)}"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
        }
        req = urllib.request.Request(nocache_url, headers=headers)
        with urllib.request.urlopen(req, timeout=3.5) as resp:
            content = resp.read().decode("utf-8")
            reader = csv.reader(io.StringIO(content))
            config = {}
            reserved_keys = {"STATUS", "MIN_VERSION", "NOTICE_MSG", "BLACKLIST_USER", "BLACKLIST_PC"}
            
            _user_alias_map.clear()
            for row in reader:
                if len(row) >= 2:
                    k = row[0].strip()
                    v = row[1].strip()
                    if not k or not v:
                        continue
                    k_upper = k.upper()
                    if k_upper in reserved_keys:
                        config[k_upper] = v
                    else:
                        _user_alias_map[k] = v

            notice_msg = config.get("NOTICE_MSG", "관리자에게 문의하세요.")

            if config.get("STATUS", "ON").upper() == "OFF":
                send_telemetry_sync("원격 차단됨(STATUS=OFF)")
                return False, f"[원격 서비스 중단]\n\n{notice_msg}"

            min_ver_raw = config.get("MIN_VERSION", APP_VERSION).strip()
            if parse_version_tuple(min_ver_raw) > parse_version_tuple(APP_VERSION):
                send_telemetry_sync(f"구버전 차단됨 (현재:{APP_VERSION}, 최소:{min_ver_raw})")
                return False, f"[버전 업데이트 필요]\n\n현재 버전: {APP_VERSION}\n최신 버전: {min_ver_raw}\n\n{notice_msg}"

            user_name, pc_name = get_client_identifiers()
            b_users = [x.strip().upper() for x in config.get("BLACKLIST_USER", "").split(",") if x.strip()]
            b_pcs = [x.strip().upper() for x in config.get("BLACKLIST_PC", "").split(",") if x.strip()]

            if user_name.upper() in b_users or pc_name.upper() in b_pcs:
                send_telemetry_sync(f"블랙리스트 차단됨 ({user_name} / {pc_name})")
                return False, "[사용 권한 제한]\n\n접근 권한이 비활성화된 계정 또는 PC입니다.\n관리자에게 문의하여 사용 권한을 요청하세요."

    except Exception:
        pass

    return True, ""

# ==========================================
# Windows COM IMessageFilter 및 엑셀 프로세스 안전 종료 제어
# ==========================================
class INTERFACE(ctypes.Structure):
    pass

class IMessageFilterVtbl(ctypes.Structure):
    _fields_ = [
        ('QueryInterface', ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)),
        ('AddRef', ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)),
        ('Release', ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)),
        ('HandleInComingCall', ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p)),
        ('RetryRejectedCall', ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD)),
        ('MessagePending', ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD))
    ]

INTERFACE._fields_ = [('lpVtbl', ctypes.POINTER(IMessageFilterVtbl))]

def _QueryInterface(this, riid, ppv): return 0
def _AddRef(this): return 1
def _Release(this): return 1
def _HandleInComingCall(this, dwCallType, htaskCaller, dwTickCount, lpInterfaceInfo): return 0
def _RetryRejectedCall(this, htaskCallee, dwTickCount, dwRejectType):
    if dwTickCount < 15000:
        return 150
    return 0xFFFFFFFF
def _MessagePending(this, htaskCallee, dwTickCount, dwPendingType): return 2

_vtbl = IMessageFilterVtbl(
    ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)(_QueryInterface),
    ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(_AddRef),
    ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(_Release),
    ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p)(_HandleInComingCall),
    ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD)(_RetryRejectedCall),
    ctypes.WINFUNCTYPE(wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD)(_MessagePending)
)
_filter_inst = INTERFACE(ctypes.pointer(_vtbl))

def enable_com_retry_filter():
    try:
        old = ctypes.c_void_p()
        ctypes.oledll.ole32.CoRegisterMessageFilter(ctypes.byref(_filter_inst), ctypes.byref(old))
    except Exception:
        pass

def disable_com_retry_filter():
    try:
        old = ctypes.c_void_p()
        ctypes.oledll.ole32.CoRegisterMessageFilter(None, ctypes.byref(old))
    except Exception:
        pass

def get_excel_pid(excel_app):
    try:
        hwnd = excel_app.Hwnd
        pid = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value
    except Exception:
        return None

def kill_process_by_pid(pid):
    if not pid:
        return
    try:
        PROCESS_TERMINATE = 0x0001
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if handle:
            ctypes.windll.kernel32.TerminateProcess(handle, 0)
            ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        pass

class AutoScrollbar(ttk.Scrollbar):
    def set(self, lo, hi):
        if float(lo) <= 0.0 and float(hi) >= 1.0:
            self.grid_remove()
        else:
            self.grid()
        ttk.Scrollbar.set(self, lo, hi)

class QCReportApp:
    def __init__(self, root):
        self.root = root
        self.lang = "ko"
        
        self.root.geometry("860x540")
        self.root.minsize(760, 480)
        self.root.configure(bg="#F0F2F5")
        
        self.input_file = tk.StringVar()
        self.output_dir = tk.StringVar()
        self.input_file.trace_add("write", self.on_file_path_changed)
        
        self.tot_data = {}
        self.detail_data = {}
        self.detail_sample_labels = {}
        self.detail_sample_coords = {}
        self.chart_render_data = {}
        self.measured_sheets = []
        
        self.integrity_tot = {}
        self.integrity_detail = {}
        
        self.btn_pct = 0
        self.is_processing = False
        self.is_analyzed = False
        self.is_save_enabled = False
        self.dot_count = 0
        
        self.is_saving = False
        self.save_pct = 0
        self.save_text_color = "#FFFFFF"
        self.color_palette = ["#FFFFFF", "#FFEB3B", "#00E5FF", "#FF80AB", "#B9F6CA", "#FFE57F", "#EA80FC"]
        
        self.hover_tip_window = None
        self.hover_current_id = None
        self.corner_r = 6

        self.credit_tip_window = None
        self.credit_color_idx = 0
        self.credit_colors = ["#E53935", "#D81B60", "#8E24AA", "#1E88E5", "#00897B", "#43A047", "#FB8C00"]
        self.credit_timer_id = None
        self.credit_text_id = None

        self.all_col_ids = ["c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10"]

        self.bg_abort_flag = threading.Event()
        self.bg_thread = None
        self.bg_temp_file = None
        self.bg_ready = False
        self.bg_lock = threading.Lock()
        self.bg_excel_pid = None

        self.texts = {
            "ko": {
                "win_title": f"초중종물 치수 분석 프로그램 ({APP_VERSION})",
                "app_title": "초중종물 치수 분석 프로그램",
                "lbl_file": " ■ 파일 선택",
                "lbl_file_sub": " (엑셀 파일을 마우스로 끌어다 놓아도 됩니다)",
                "btn_file": "파일 선택",
                "lbl_dir": " ■ 저장 위치",
                "lbl_dir_sub": " (미선택 시 파일과 같은 폴더)",
                "btn_dir": "폴더 선택",
                "btn_run": "자료 분석 및  보고서 작성",
                "btn_save": "파일 저장",
                "lbl_preview": " ■ 분석 결과 미리보기",
                "lbl_preview_sub": " (항목에 마우스를 올리면 미니 그래프가 표시됩니다)",
                "status_ready": "준비됨",
                "analyzing": "분석중",
                "done_pct": "%완료",
                "saving_prefix": "작성중",
                "save_done": "파일 저장완료",
                "btn_confirm": "확인",
                "cols": ["공정/품명", "측정항목", "규격", "평균", "최소", "최대", "이탈수", "Cpk", "상하MAX", "판정", "세부원인"],
                "err_no_data": "엑셀 파일에 검토할 치수 data가 없습니다",
                "err_no_file": "분석할 엑셀 파일을 먼저 선택해 주세요.",
                "notice_no_meas": "유효한 측정 데이터를 찾지 못했습니다.",
                "status_done_guide": "분석 완료! [파일 저장]을 눌러 보고서를 저장하세요.",
                "excel_t1_title": "1. 공정/항목별 종합 산포 요약 보고서 (통합)",
                "excel_t1_headers": [("B3", "공정/품명"), ("C3", "치수 분포"), ("F3", "측정항목"), ("G3", "규격"),
                                     ("H3", "평균"), ("I3", "최소"), ("J3", "최대"), ("K3", "이탈수"),
                                     ("L3", "Cpk"), ("M3", "상하MAX"), ("N3", "판정"), ("O3", "세부원인")],
                "excel_t2_title": "2. 세부 산포 요약 보고서 (Date / Mold / Cavity 별)",
                "excel_t2_headers": ["구분", "DATE", "MOLD", "CAVITY", "측정항목", "규격", "평균", "최소", "최대", "이탈수", "Cpk", "상하MAX", "판정", "세부원인", "조작의심 세부근거"],
                "suspect_label": "data 조작의심",
                "suspect_zero_tag": "[전수 동일값]",
                "suspect_zero_suffix": "전수 동일",
                "suspect_dup_tag": "[3개값 같음]"
            },
            "vi": {
                "win_title": f"Chương trình phân tích kích thước đầu/giữa/cuối ({APP_VERSION})",
                "app_title": "Chương trình phân tích kích thước",
                "lbl_file": " ■ Chọn tệp",
                "lbl_file_sub": " (Có thể kéo thả tệp Excel vào đây)",
                "btn_file": "Chọn tệp",
                "lbl_dir": " ■ Vị trí lưu",
                "lbl_dir_sub": " (Nếu không chọn, lưu cùng thư mục gốc)",
                "btn_dir": "Chọn thư mục",
                "btn_run": "Phân tích dữ liệu & Tạo báo cáo",
                "btn_save": "Lưu tệp",
                "lbl_preview": " ■ Xem trước kết quả",
                "lbl_preview_sub": " (Rê chuột vào mục để xem biểu đồ nhỏ)",
                "status_ready": "Sẵn sàng",
                "analyzing": "Đang phân tích",
                "done_pct": "% xong",
                "saving_prefix": "Đang tạo",
                "save_done": "파일 저장완료",
                "btn_confirm": "Xác nhận",
                "cols": ["Công đoạn/SP", "Hạng mục", "Quy cách", "Trung bình", "Tối thiểu", "Tối đa", "Số lỗi", "Cpk", "Cận Max/Min", "Đánh giá", "Nguyên nhân"],
                "err_no_data": "엑셀 파일에 검토할 치수 data가 없습니다",
                "err_no_file": "Vui lòng chọn tệp Excel trước khi phân tích.",
                "notice_no_meas": "Không tìm thấy dữ liệu đo lường hợp lệ.",
                "status_done_guide": "Hoàn tất! Hãy bấm [Lưu tệp] để lưu báo cáo.",
                "excel_t1_title": "1. Báo cáo tóm tắt phân tán tổng hợp theo công đoạn/hạng mục (Tổng hợp)",
                "excel_t1_headers": [("B3", "Công đoạn/SP"), ("C3", "Phân bố kích thước"), ("F3", "Hạng mục"), ("G3", "Quy cách"),
                                     ("H3", "Trung bình"), ("I3", "Tối thiểu"), ("J3", "Tối đa"), ("K3", "Số lỗi"),
                                     ("L3", "Cpk"), ("M3", "Cận Max/Min"), ("N3", "Đánh giá"), ("O3", "Nguyên nhân chi tiết")],
                "excel_t2_title": "2. Báo cáo chi tiết phân tán (Theo Date / Mold / Cavity)",
                "excel_t2_headers": ["Phân loại", "DATE", "MOLD", "CAVITY", "Hạng mục", "Quy cách", "Trung bình", "Tối thiểu", "Tối đa", "Số lỗi", "Cpk", "Cận Max/Min", "Đánh giá", "Nguyên nhân chi tiết", "Căn cứ nghi ngờ"],
                "suspect_label": "Nghi ngờ dữ liệu",
                "suspect_zero_tag": "[Đồng nhất toàn bộ]",
                "suspect_zero_suffix": "toàn bộ đồng nhất",
                "suspect_dup_tag": "[3 giá trị trùng]"
            }
        }

        self.style = ttk.Style()
        self.style.theme_use("clam")
        
        self.style.configure("Custom.Treeview", background="#FFFFFF", fieldbackground="#FFFFFF", foreground="#1E293B", rowheight=23, bordercolor="#E2E8F0", font=("Malgun Gothic", 9))
        self.style.configure("Custom.Treeview.Heading", background="#E9ECEF", foreground="#1E293B", font=("Malgun Gothic", 9, "bold"), relief="flat", padding=3)
        self.style.map("Custom.Treeview.Heading", background=[('active', '#DEE2E6')])
        self.style.configure("TScrollbar", background="#CBD5E1", troughcolor="#F1F5F9", bordercolor="#F1F5F9", arrowcolor="#64748B")

        self.build_ui()
        self.set_language("ko")
        self.root.protocol("WM_DELETE_WINDOW", self.on_app_closing)

    def on_app_closing(self):
        try:
            self.abort_background_prefetch()
        except Exception:
            pass
        self.root.destroy()
        sys.exit(0)

    def on_file_path_changed(self, *args):
        if self.is_analyzed:
            self.is_analyzed = False
            self.draw_main_button()

    def abort_background_prefetch(self):
        self.bg_abort_flag.set()
        with self.bg_lock:
            self.bg_ready = False
            if self.bg_excel_pid:
                kill_process_by_pid(self.bg_excel_pid)
                self.bg_excel_pid = None
            if self.bg_temp_file and os.path.exists(self.bg_temp_file):
                try:
                    os.remove(self.bg_temp_file)
                except Exception:
                    pass
                self.bg_temp_file = None

    @staticmethod
    def compute_stats(vals, spec, utol, ltol, lang="ko"):
        n = len(vals)
        mean_v = sum(vals) / n if n > 0 else 0.0
        min_v = min(vals) if n > 0 else 0.0
        max_v = max(vals) if n > 0 else 0.0
        std_v = statistics.stdev(vals) if n > 1 else 0.0001
        if std_v == 0:
            std_v = 0.0001
            
        usl, lsl = spec + utol, spec + ltol
        out_c = sum(1 for v in vals if v > usl or v < lsl)
        cpk = min((usl - mean_v) / (3 * std_v), (mean_v - lsl) / (3 * std_v))
        
        near_v = [f"{v:.2f}" for v in vals if abs(usl - v) <= 0.0101 or abs(v - lsl) <= 0.0101]
        near_s = ", ".join(sorted(list(set(near_v)))) if near_v else ("없음" if lang == "ko" else "Không")
        
        issues = []
        if out_c > 0:
            issues.append(f"규격 이탈 ({out_c}개)" if lang == "ko" else f"Vượt quy cách ({out_c})")
        if cpk < 1.0:
            issues.append("Cpk < 1.00 (공정능력 부족)" if lang == "ko" else "Cpk < 1.00 (Thiếu năng lực)")
        elif cpk <= 1.05:
            issues.append("Cpk <= 1.05 (잠재 위험)" if lang == "ko" else "Cpk <= 1.05 (Tiềm ẩn rủi ro)")
        if near_s not in ("없음", "Không"):
            issues.append(f"상하한 근접 ({near_s})" if lang == "ko" else f"Cận giới hạn ({near_s})")
        
        judge = "NG" if (out_c > 0 or cpk < 1.0) else (("경고" if lang == "ko" else "Cảnh báo") if cpk <= 1.05 else "OK")
        display_tag = "경고" if (judge == "OK" and len(issues) > 0) else judge

        return {
            "arr": vals, "n": n, "mean": mean_v, "min": min_v, "max": max_v, "std": std_v,
            "usl": usl, "lsl": lsl, "out_c": out_c, "cpk": cpk, "near_s": near_s,
            "issues": issues, "judge": judge, "display_tag": display_tag
        }

    def analyze_data_integrity(self):
        self.integrity_tot.clear()
        self.integrity_detail.clear()
        t = self.texts[self.lang]
        
        seq_dict = {}
        for d_key, vals in self.detail_data.items():
            item_name = d_key[5]
            if item_name not in seq_dict:
                seq_dict[item_name] = []
            lbls = self.detail_sample_labels.get(d_key, [f"#{i+1}" for i in range(len(vals))])
            coords = self.detail_sample_coords.get(d_key, ["" for _ in range(len(vals))])
            seq_dict[item_name].append((d_key, vals, lbls, coords))

        for item_name, block_list in seq_dict.items():
            reported_pairs = set()

            for i in range(len(block_list)):
                key_i, vals_i, lbls_i, coords_i = block_list[i]
                reasons = []
                detail_evidence = []
                
                if len(vals_i) >= 3 and len(set(vals_i)) == 1:
                    reasons.append("suspect_zero")
                    c_start = coords_i[0] if coords_i and coords_i[0] else lbls_i[0]
                    c_end = coords_i[-1] if coords_i and coords_i[-1] else lbls_i[-1]
                    cell_range = f"{c_start}~{c_end}" if c_start != c_end else c_start
                    lbl_range = f"{lbls_i[0]}~{lbls_i[-1]}" if len(lbls_i) > 1 else lbls_i[0]
                    detail_evidence.append(f"{t['suspect_zero_tag']} {cell_range} ({lbl_range}) {vals_i[0]} {t['suspect_zero_suffix']}")

                for j in range(i + 1, len(block_list)):
                    key_j, vals_j, lbls_j, coords_j = block_list[j]
                    if len(vals_i) >= 3 and len(vals_j) >= 3:
                        matched = False
                        match_info = ""
                        for p in range(len(vals_i) - 2):
                            sub_seq = vals_i[p:p+3]
                            for q in range(len(vals_j) - 2):
                                if vals_j[q:q+3] == sub_seq:
                                    pair_key = (key_i, key_j, p, q)
                                    if pair_key not in reported_pairs:
                                        reported_pairs.add(pair_key)
                                        matched = True
                                        val_str = ", ".join([str(x) for x in sub_seq])
                                        c_range_i = f"{coords_i[p]}~{coords_i[p+2]}" if coords_i[p] and coords_i[p+2] else f"{lbls_i[p]}~{lbls_i[p+2]}"
                                        c_range_j = f"{coords_j[q]}~{coords_j[q+2]}" if coords_j[q] and coords_j[q+2] else f"{lbls_j[q]}~{lbls_j[q+2]}"
                                        match_info = f"{t['suspect_dup_tag']} {c_range_i} -> {c_range_j} ({val_str})"
                                        break
                            if matched: break
                        if matched:
                            reasons.append("suspect_dup")
                            detail_evidence.append(match_info)
                            break
                            
                if reasons:
                    self.integrity_detail[key_i] = {
                        "types": list(set(reasons)),
                        "evidence": " | ".join(detail_evidence)
                    }

        for t_key in self.tot_data.keys():
            t_item = t_key[2]
            types_set = set()
            ev_list = []
            for d_key, info in self.integrity_detail.items():
                if d_key[5] == t_item:
                    types_set.update(info["types"])
                    ev_list.append(info["evidence"])
            if types_set:
                self.integrity_tot[t_key] = {
                    "types": list(types_set),
                    "evidence": " | ".join(ev_list[:3])
                }

    def draw_round_rect(self, canvas, x1, y1, x2, y2, radius=6, **kwargs):
        points = [
            x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
            x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
            x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1
        ]
        return canvas.create_polygon(points, **kwargs, smooth=True)

    def draw_lang_badge(self, cv, code, is_active):
        cv.delete("all")
        w, h, r = 38, 25, self.corner_r
        if is_active:
            self.draw_round_rect(cv, 1, 1, w - 1, h - 1, radius=r, fill="#1565C0", outline="#0D47A1")
            cv.create_text(w / 2, h / 2, text=code, fill="#FFFFFF", font=("Malgun Gothic", 9, "bold"))
        else:
            self.draw_round_rect(cv, 1, 1, w - 1, h - 1, radius=r, fill="#FFFFFF", outline="#CED4DA")
            cv.create_text(w / 2, h / 2, text=code, fill="#64748B", font=("Malgun Gothic", 9, "bold"))

    def render_lang_badges(self):
        self.draw_lang_badge(self.cv_flag_kr, "KO", self.lang == "ko")
        self.draw_lang_badge(self.cv_flag_vn, "VN", self.lang == "vi")

    def build_ui(self):
        frame_header = tk.Frame(self.root, bg="#F0F2F5", padx=14)
        frame_header.pack(fill="x", pady=(8, 2))

        self.title_lbl = tk.Label(frame_header, text=self.texts[self.lang]["app_title"], 
                                  font=("Malgun Gothic", 15, "bold"), fg="#1565C0", bg="#F0F2F5")
        self.title_lbl.grid(row=0, column=0, sticky="w", padx=4)

        frame_flags = tk.Frame(frame_header, bg="#F0F2F5", width=86)
        frame_flags.grid(row=0, column=1, sticky="e", padx=4)
        frame_flags.grid_propagate(False)

        self.cv_flag_kr = tk.Canvas(frame_flags, width=38, height=25, bg="#F0F2F5", highlightthickness=0, cursor="hand2")
        self.cv_flag_kr.pack(side="left", padx=(0, 3))
        self.cv_flag_kr.bind("<Button-1>", lambda e: self.on_language_select("ko"))

        self.cv_flag_vn = tk.Canvas(frame_flags, width=38, height=25, bg="#F0F2F5", highlightthickness=0, cursor="hand2")
        self.cv_flag_vn.pack(side="left")
        self.cv_flag_vn.bind("<Button-1>", lambda e: self.on_language_select("vi"))

        frame_header.columnconfigure(0, weight=1)

        frame_form = tk.Frame(self.root, bg="#F0F2F5", padx=14)
        frame_form.pack(fill="x")

        f_lbl1 = tk.Frame(frame_form, bg="#F0F2F5")
        f_lbl1.grid(row=0, column=0, sticky="w", pady=(1, 1))
        self.lbl_file = tk.Label(f_lbl1, text=self.texts[self.lang]["lbl_file"], font=("Malgun Gothic", 9, "bold"), fg="#333333", bg="#F0F2F5")
        self.lbl_file.pack(side="left")
        self.lbl_file_sub = tk.Label(f_lbl1, text=self.texts[self.lang]["lbl_file_sub"], font=("Malgun Gothic", 8), fg="#777777", bg="#F0F2F5")
        self.lbl_file_sub.pack(side="left")

        self.cv_entry_file = tk.Canvas(frame_form, height=32, bg="#F0F2F5", highlightthickness=0)
        self.cv_entry_file.grid(row=1, column=0, padx=4, pady=(1, 3), sticky="we")
        self.cv_entry_file.bind("<Configure>", lambda e: self.draw_input_box(self.cv_entry_file))

        self.entry_file = tk.Entry(self.cv_entry_file, textvariable=self.input_file, font=("Malgun Gothic", 10),
                                   bg="#FFFFFF", fg="#212529", bd=0, highlightthickness=0)
        self.entry_file.place(x=8, y=5, relwidth=0.97, height=22)
        self.entry_file.drop_target_register(DND_FILES)
        self.entry_file.dnd_bind('<<Drop>>', self.drop_file)

        self.btn_file_cv = tk.Canvas(frame_form, width=86, height=32, bg="#F0F2F5", highlightthickness=0, cursor="hand2")
        self.btn_file_cv.grid(row=1, column=1, padx=4, pady=(1, 3))
        self.btn_file_cv.bind("<Configure>", lambda e: self.draw_sub_btn(self.btn_file_cv, self.texts[self.lang]["btn_file"]))
        self.btn_file_cv.bind("<Button-1>", lambda e: self.browse_file())

        f_lbl2 = tk.Frame(frame_form, bg="#F0F2F5")
        f_lbl2.grid(row=2, column=0, sticky="w", pady=(1, 1))
        self.lbl_dir = tk.Label(f_lbl2, text=self.texts[self.lang]["lbl_dir"], font=("Malgun Gothic", 9, "bold"), fg="#333333", bg="#F0F2F5")
        self.lbl_dir.pack(side="left")
        self.lbl_dir_sub = tk.Label(f_lbl2, text=self.texts[self.lang]["lbl_dir_sub"], font=("Malgun Gothic", 8), fg="#777777", bg="#F0F2F5")
        self.lbl_dir_sub.pack(side="left")

        self.cv_entry_dir = tk.Canvas(frame_form, height=32, bg="#F0F2F5", highlightthickness=0)
        self.cv_entry_dir.grid(row=3, column=0, padx=4, pady=(1, 3), sticky="we")
        self.cv_entry_dir.bind("<Configure>", lambda e: self.draw_input_box(self.cv_entry_dir))

        entry_dir = tk.Entry(self.cv_entry_dir, textvariable=self.output_dir, font=("Malgun Gothic", 10),
                             bg="#FFFFFF", fg="#212529", bd=0, highlightthickness=0)
        entry_dir.place(x=8, y=5, relwidth=0.97, height=22)

        self.btn_dir_cv = tk.Canvas(frame_form, width=86, height=32, bg="#F0F2F5", highlightthickness=0, cursor="hand2")
        self.btn_dir_cv.grid(row=3, column=1, padx=4, pady=(1, 3))
        self.btn_dir_cv.bind("<Configure>", lambda e: self.draw_sub_btn(self.btn_dir_cv, self.texts[self.lang]["btn_dir"]))
        self.btn_dir_cv.bind("<Button-1>", lambda e: self.browse_dir())

        self.btn_canvas = tk.Canvas(frame_form, height=36, bg="#F0F2F5", highlightthickness=0, cursor="hand2")
        self.btn_canvas.grid(row=4, column=0, padx=4, pady=(5, 6), sticky="we")
        self.btn_canvas.bind("<Configure>", self.draw_main_button)
        self.btn_canvas.bind("<Button-1>", lambda e: self.process_data())

        self.btn_save_canvas = tk.Canvas(frame_form, width=86, height=36, bg="#F0F2F5", highlightthickness=0, cursor="arrow")
        self.btn_save_canvas.grid(row=4, column=1, padx=4, pady=(5, 6))
        self.btn_save_canvas.bind("<Configure>", self.draw_save_button)
        self.btn_save_canvas.bind("<Button-1>", lambda e: self.on_save_button_click())

        frame_form.columnconfigure(0, weight=1)

        frame_preview_wrap = tk.Frame(self.root, bg="#F0F2F5", padx=14, pady=1)
        frame_preview_wrap.pack(fill="both", expand=True)

        f_lbl3 = tk.Frame(frame_preview_wrap, bg="#F0F2F5")
        f_lbl3.pack(fill="x", padx=4, pady=(0, 1))
        self.lbl_preview = tk.Label(f_lbl3, text=self.texts[self.lang]["lbl_preview"], font=("Malgun Gothic", 9, "bold"), fg="#333333", bg="#F0F2F5")
        self.lbl_preview.pack(side="left")
        self.lbl_preview_sub = tk.Label(f_lbl3, text=self.texts[self.lang]["lbl_preview_sub"], 
                                        font=("Malgun Gothic", 8), fg="#777777", bg="#F0F2F5")
        self.lbl_preview_sub.pack(side="left")

        self.cv_tree_card = tk.Canvas(frame_preview_wrap, bg="#F0F2F5", highlightthickness=0)
        self.cv_tree_card.pack(fill="both", expand=True, padx=4, pady=(1, 4))
        self.cv_tree_card.bind("<Configure>", self.draw_tree_card_border)

        frame_tree = tk.Frame(self.cv_tree_card, bg="#FFFFFF", bd=0)
        self.cv_tree_card.create_window(3, 3, window=frame_tree, anchor="nw", tags="tree_win")

        self.tree = ttk.Treeview(frame_tree, columns=self.all_col_ids, show="headings", style="Custom.Treeview")

        scroll_y = AutoScrollbar(frame_tree, orient="vertical", command=self.tree.yview)
        scroll_x = AutoScrollbar(frame_tree, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x.grid(row=1, column=0, sticky="ew")

        frame_tree.rowconfigure(0, weight=1)
        frame_tree.columnconfigure(0, weight=1)

        self.tree.bind("<Button-1>", self.disable_col_resize, add="+")
        self.tree.bind("<B1-Motion>", self.disable_col_resize, add="+")
        self.tree.bind("<Motion>", self.on_tree_mouse_motion)
        self.tree.bind("<Leave>", self.on_tree_mouse_leave)
        self.tree.tag_configure("even", background="#FFFFFF")
        self.tree.tag_configure("odd", background="#F1F5F9")
        self.tree.tag_configure("NG", foreground="#DC3545")
        self.tree.tag_configure("경고", foreground="#FD7E14")
        self.tree.tag_configure("OK", foreground="#198754")
        self.tree.tag_configure("SUSPECT", foreground="#6F42C1", font=("Malgun Gothic", 9, "bold"))

        frame_status = tk.Frame(self.root, bg="#E9ECEF", padx=14, pady=8)
        frame_status.pack(side="bottom", fill="x")
        
        self.lbl_status = tk.Label(frame_status, text=self.texts[self.lang]["status_ready"], relief="flat", anchor="w", 
                                   font=("Malgun Gothic", 9), fg="#333333", bg="#E9ECEF")
        self.lbl_status.pack(side="left", fill="x", expand=True)

        self.lbl_credit = tk.Label(frame_status, text="Made by jung seung jae", relief="flat", anchor="e",
                                   font=("Malgun Gothic", 7), fg="#808080", bg="#E9ECEF", cursor="hand2")
        self.lbl_credit.pack(side="right", pady=(3, 0))
        self.lbl_credit.bind("<Enter>", self.on_credit_enter)
        self.lbl_credit.bind("<Motion>", self.on_credit_motion)
        self.lbl_credit.bind("<Leave>", self.on_credit_leave)

    def on_credit_enter(self, event):
        if self.credit_tip_window:
            return

        mx = self.root.winfo_pointerx() + 12
        my = self.root.winfo_pointery() - 24

        font_credit = tkfont.Font(family="Malgun Gothic", size=7, weight="bold")
        text_w = font_credit.measure("1980latium.003@gmail.com")
        
        pad_x, pad_y = 5, 3
        w_pop = text_w + (pad_x * 2) + 2
        h_pop = font_credit.metrics("linespace") + (pad_y * 2) + 2

        self.credit_tip_window = tk.Toplevel(self.root)
        self.credit_tip_window.wm_overrideredirect(True)
        self.credit_tip_window.wm_attributes("-topmost", True)
        self.credit_tip_window.geometry(f"{w_pop}x{h_pop}+{mx}+{my}")
        self.credit_tip_window.configure(bg="#F0F2F5")

        self.cv_credit_pop = tk.Canvas(self.credit_tip_window, width=w_pop, height=h_pop, 
                                       bg="#F0F2F5", highlightthickness=0)
        self.cv_credit_pop.pack(fill="both", expand=True)

        self.draw_round_rect(self.cv_credit_pop, 1, 1, w_pop - 2, h_pop - 2, 
                             radius=self.corner_r, fill="#FFFFFF", outline="#1565C0", width=1)

        self.credit_color_idx = 0
        self.credit_text_id = self.cv_credit_pop.create_text(
            w_pop / 2, h_pop / 2,
            text="1980latium.003@gmail.com",
            font=font_credit,
            fill=self.credit_colors[0]
        )

        self.animate_credit_color()

    def on_credit_motion(self, event):
        if self.credit_tip_window:
            mx = self.root.winfo_pointerx() + 12
            my = self.root.winfo_pointery() - 24
            self.credit_tip_window.geometry(f"+{mx}+{my}")

    def animate_credit_color(self):
        if not self.credit_tip_window or not hasattr(self, "cv_credit_pop"):
            return
        self.credit_color_idx = (self.credit_color_idx + 1) % len(self.credit_colors)
        try:
            self.cv_credit_pop.itemconfigure(self.credit_text_id, fill=self.credit_colors[self.credit_color_idx])
            self.credit_timer_id = self.root.after(200, self.animate_credit_color)
        except Exception:
            pass

    def on_credit_leave(self, event):
        if self.credit_timer_id:
            self.root.after_cancel(self.credit_timer_id)
            self.credit_timer_id = None
        if self.credit_tip_window:
            self.credit_tip_window.destroy()
            self.credit_tip_window = None

    def on_language_select(self, target_lang):
        if self.is_processing or self.is_saving:
            return
        if self.lang != target_lang:
            self.set_language(target_lang)

    def set_language(self, lang):
        self.lang = lang
        t = self.texts[lang]
        self.root.title(t["win_title"])
        self.title_lbl.config(text=t["app_title"])
        self.lbl_file.config(text=t["lbl_file"])
        self.lbl_file_sub.config(text=t["lbl_file_sub"])
        self.lbl_dir.config(text=t["lbl_dir"])
        self.lbl_dir_sub.config(text=t["lbl_dir_sub"])
        self.lbl_preview.config(text=t["lbl_preview"])
        self.lbl_preview_sub.config(text=t["lbl_preview_sub"])
        self.lbl_status.config(text=t["status_ready"])
        
        self.draw_sub_btn(self.btn_file_cv, t["btn_file"])
        self.draw_sub_btn(self.btn_dir_cv, t["btn_dir"])
        self.draw_main_button()
        self.draw_save_button()
        self.render_lang_badges()

        for i, cid in enumerate(self.all_col_ids):
            self.tree.heading(cid, text=t["cols"][i])

        if self.tot_data:
            self.analyze_data_integrity()
            self.refresh_treeview_rows()
            self.rebuild_chart_render_data()
            self.autofit_treeview_columns()
        else:
            self.apply_initial_compact_columns()

    def apply_initial_compact_columns(self):
        measure_font = tkfont.Font(family="Malgun Gothic", size=9)
        t = self.texts[self.lang]
        for i, cid in enumerate(self.all_col_ids):
            txt = t["cols"][i]
            w = measure_font.measure(txt) + 20
            self.tree.column(cid, width=max(48, w), anchor="center", stretch=False)
        self.tree.column("c0", anchor="center")
        self.tree.column("c1", anchor="w")
        self.tree.column("c10", anchor="w")

    def refresh_treeview_rows(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        t = self.texts[self.lang]
        row_idx = 0
        for (sheet, proc, item_name, spec, utol, ltol), vals in self.tot_data.items():
            t_key = (sheet, proc, item_name, spec, utol, ltol)
            st = self.compute_stats(vals, spec, utol, ltol, self.lang)
            
            display_item_name = translate_measure_name(item_name, self.lang)

            suspect_info = self.integrity_tot.get(t_key, None)
            suspect_reasons = []
            if suspect_info:
                suspect_reasons.append(t["suspect_label"])

            combined_issues = st["issues"] + suspect_reasons

            row_vals = (
                proc, display_item_name, f"{spec:.2f} (±{utol:.2f})",
                f"{st['mean']:.2f}", f"{st['min']:.2f}", f"{st['max']:.2f}",
                f"{st['out_c']}/{st['n']}", f"{st['cpk']:.2f}", st["near_s"],
                st["judge"], ", ".join(combined_issues)
            )
            
            tag_bg = "even" if row_idx % 2 == 0 else "odd"
            tag_stat = "SUSPECT" if suspect_reasons else st["display_tag"]
            
            item_iid = f"row_{row_idx}"
            self.tree.insert("", "end", iid=item_iid, values=row_vals, tags=(tag_stat, tag_bg))
            row_idx += 1

    def rebuild_chart_render_data(self):
        self.chart_render_data.clear()
        num_bins = 15
        tree_children = self.tree.get_children()
        for tree_id, ((sheet, proc, item_name, spec, utol, ltol), vals) in zip(tree_children, self.tot_data.items()):
            st = self.compute_stats(vals, spec, utol, ltol, self.lang)
            x_min = min(st["min"], st["lsl"]) - (0.5 * st["std"])
            x_max = max(st["max"], st["usl"]) + (0.5 * st["std"])
            bin_w = (x_max - x_min) / num_bins
            if bin_w <= 0: bin_w = 0.001
            
            bin_centers = [x_min + (b + 0.5) * bin_w for b in range(num_bins)]
            counts = self._calc_histogram(st["arr"], num_bins, x_min, x_max)
            norm_vals = [(1 / (st["std"] * math.sqrt(2 * math.pi))) * math.exp(-0.5 * ((bc - st["mean"]) / st["std"]) ** 2) * st["n"] * bin_w for bc in bin_centers]

            diff_l = [abs(bc - st["lsl"]) for bc in bin_centers]
            diff_s = [abs(bc - spec) for bc in bin_centers]
            diff_u = [abs(bc - st["usl"]) for bc in bin_centers]

            self.chart_render_data[tree_id] = {
                "counts": counts, "norm_vals": norm_vals,
                "idx_l": diff_l.index(min(diff_l)) + 1,
                "idx_s": diff_s.index(min(diff_s)) + 1,
                "idx_u": diff_u.index(min(diff_u)) + 1
            }

    def draw_tree_card_border(self, event):
        w, h = event.width, event.height
        self.cv_tree_card.delete("border_bg")
        self.draw_round_rect(self.cv_tree_card, 1, 1, w - 2, h - 2, radius=self.corner_r, 
                             fill="#FFFFFF", outline="#CED4DA", tags="border_bg")
        self.cv_tree_card.tag_lower("border_bg")
        
        tw, th = max(10, w - 6), max(10, h - 6)
        for win in self.cv_tree_card.find_withtag("tree_win"):
            self.cv_tree_card.itemconfigure(win, width=tw, height=th)
        
        if self.tot_data:
            self.autofit_treeview_columns()
        else:
            self.apply_initial_compact_columns()

    def draw_input_box(self, canvas):
        canvas.delete("box_bg")
        w, h = canvas.winfo_width(), canvas.winfo_height()
        if w > 10 and h > 10:
            self.draw_round_rect(canvas, 1, 1, w - 2, h - 2, radius=self.corner_r, 
                                 fill="#FFFFFF", outline="#CED4DA", tags="box_bg")
            canvas.tag_lower("box_bg")

    def draw_sub_btn(self, canvas, text):
        canvas.delete("all")
        w, h = canvas.winfo_width(), canvas.winfo_height()
        if w < 10 or h < 10: return
        self.draw_round_rect(canvas, 1, 1, w - 2, h - 2, radius=self.corner_r, fill="#F8F9FA", outline="#CED4DA")
        canvas.create_text(w / 2, h / 2, text=text, fill="#212529", font=("Malgun Gothic", 9, "bold"))

    def disable_col_resize(self, event):
        widget = event.widget
        if widget.identify_region(event.x, event.y) == "separator":
            return "break"

    def animate_dots(self):
        if not self.is_processing: return
        self.dot_count = (self.dot_count + 1) % 4
        self.draw_main_button()
        self.root.after(500, self.animate_dots)

    def animate_saving_color(self):
        if not self.is_saving:
            self.save_text_color = "#FFFFFF"
            return
        self.save_text_color = random.choice(self.color_palette)
        self.draw_save_button()
        self.root.after(200, self.animate_saving_color)

    def draw_main_button(self, event=None):
        self.btn_canvas.delete("all")
        w, h = self.btn_canvas.winfo_width(), self.btn_canvas.winfo_height()
        if w < 10 or h < 10: return

        r = self.corner_r
        t = self.texts[self.lang]
        if self.is_processing:
            self.draw_round_rect(self.btn_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#C8E6C9", outline="#A5D6A7")
            fill_w = max(r * 2, w * (self.btn_pct / 100.0))
            self.draw_round_rect(self.btn_canvas, 1, 1, fill_w, h - 2, radius=r, fill="#388E3C", outline="#2E7D32")
            dots_str = "." * self.dot_count
            self.btn_canvas.create_text(18, h / 2, anchor="w", 
                                        text=f"{t['analyzing']}{dots_str} {int(self.btn_pct)}{t['done_pct']}", 
                                        fill="white", font=("Malgun Gothic", 9, "bold"))
            self.btn_canvas.config(cursor="arrow")
        elif self.is_analyzed:
            self.draw_round_rect(self.btn_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#CFD8DC", outline="#B0BEC5")
            self.btn_canvas.create_text(w / 2, h / 2, text=t["btn_run"], fill="#78909C", font=("Malgun Gothic", 10, "bold"))
            self.btn_canvas.config(cursor="arrow")
        else:
            self.draw_round_rect(self.btn_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#4CAF50", outline="#43A047")
            self.btn_canvas.create_text(w / 2, h / 2, text=t["btn_run"], fill="white", font=("Malgun Gothic", 10, "bold"))
            self.btn_canvas.config(cursor="hand2")

    def draw_save_button(self, event=None):
        self.btn_save_canvas.delete("all")
        w, h = self.btn_save_canvas.winfo_width(), self.btn_save_canvas.winfo_height()
        if w < 10 or h < 10: return

        r = self.corner_r
        t = self.texts[self.lang]
        if self.is_saving:
            self.draw_round_rect(self.btn_save_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#A5D6A7", outline="#81C784")
            fill_w = max(r * 2, w * (self.save_pct / 100.0))
            self.draw_round_rect(self.btn_save_canvas, 1, 1, fill_w, h - 2, radius=r, fill="#1B5E20", outline="#144A18")
            btn_txt = f"{t['saving_prefix']} {int(self.save_pct)}%"
            self.btn_save_canvas.create_text(w / 2, h / 2, text=btn_txt, fill=self.save_text_color, font=("Malgun Gothic", 8, "bold"))
            self.btn_save_canvas.config(cursor="arrow")
        elif self.is_save_enabled:
            self.draw_round_rect(self.btn_save_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#2E7D32", outline="#1B5E20")
            self.btn_save_canvas.create_text(w / 2, h / 2, text=t["btn_save"], fill="white", font=("Malgun Gothic", 9, "bold"))
            self.btn_save_canvas.config(cursor="hand2")
        else:
            self.draw_round_rect(self.btn_save_canvas, 1, 1, w - 2, h - 2, radius=r, fill="#CFD8DC", outline="#B0BEC5")
            self.btn_save_canvas.create_text(w / 2, h / 2, text=t["btn_save"], fill="#78909C", font=("Malgun Gothic", 9, "bold"))
            self.btn_save_canvas.config(cursor="arrow")

    def update_save_progress(self, pct, status_text=""):
        self.is_saving = True
        self.save_pct = max(0, min(100, pct))
        self.draw_save_button()
        if status_text:
            self.lbl_status.config(text=status_text)
        self.root.update()

    def on_save_button_click(self):
        if self.is_saving or self.is_processing or not self.is_save_enabled:
            return
        self.save_excel_report()

    def update_btn_progress(self, pct, status_text=""):
        self.is_processing = True
        self.btn_pct = max(0, min(100, pct))
        self.draw_main_button()
        if status_text:
            self.lbl_status.config(text=status_text)
        self.root.update()

    def finish_btn_progress(self, status_text=""):
        self.is_processing = False
        self.btn_pct = 0
        self.dot_count = 0
        self.draw_main_button()
        if status_text:
            self.lbl_status.config(text=status_text)
        self.root.update()

    def drop_file(self, event):
        if self.is_processing or self.is_saving:
            return
        file_path = event.data.strip()
        if file_path.startswith('{') and file_path.endswith('}'):
            file_path = file_path[1:-1]
        file_path = os.path.normpath(file_path.replace('"', '').replace("'", ""))
        
        if file_path.lower().endswith(('.xlsx', '.xlsm', '.xls')):
            self.abort_background_prefetch()
            self.is_analyzed = False
            self.input_file.set(file_path)
            if not self.output_dir.get():
                self.output_dir.set(os.path.dirname(file_path))
            self.draw_main_button()
        else:
            messagebox.showwarning("오류", "엑셀 파일(.xlsx, .xlsm, .xls)만 끌어다 놓을 수 있습니다.")

    def browse_file(self):
        if self.is_processing or self.is_saving:
            return
        f = filedialog.askopenfilename(filetypes=[("Excel Files", "*.xlsx *.xlsm *.xls")])
        if f:
            self.abort_background_prefetch()
            self.is_analyzed = False
            f = os.path.normpath(f)
            self.input_file.set(f)
            if not self.output_dir.get():
                self.output_dir.set(os.path.dirname(f))
            self.draw_main_button()

    def browse_dir(self):
        if self.is_processing or self.is_saving:
            return
        d = filedialog.askdirectory()
        if d:
            self.output_dir.set(os.path.normpath(d))

    def autofit_treeview_columns(self):
        measure_font = tkfont.Font(family="Malgun Gothic", size=9)
        t = self.texts[self.lang]
        
        col_max_widths = {}
        for i, cid in enumerate(self.all_col_ids):
            col_max_widths[cid] = measure_font.measure(t["cols"][i]) + 24

        for item_id in self.tree.get_children():
            row_vals = self.tree.item(item_id, "values")
            for cid, val in zip(self.all_col_ids, row_vals):
                w = measure_font.measure(str(val)) + 22
                if w > col_max_widths[cid]:
                    col_max_widths[cid] = w

        for i, cid in enumerate(self.all_col_ids):
            calculated_w = col_max_widths[cid]
            if cid == "c0":
                self.tree.column(cid, width=max(80, int(calculated_w)), anchor="center", stretch=False)
            elif cid == "c1":
                self.tree.column(cid, width=max(90, int(calculated_w)), anchor="w", stretch=False)
            elif cid == "c2":
                self.tree.column(cid, width=max(85, int(calculated_w)), anchor="center", stretch=False)
            elif cid == "c10":
                self.tree.column(cid, width=max(180, int(calculated_w)), anchor="w", stretch=False)
            else:
                self.tree.column(cid, width=max(55, int(calculated_w)), anchor="center", stretch=False)

    def on_tree_mouse_motion(self, event):
        widget = event.widget
        item_id = widget.identify_row(event.y)
        if not item_id or item_id not in self.chart_render_data:
            self.hide_hover_tip()
            return

        mouse_x, mouse_y = event.x_root + 18, event.y_root - 10
        if self.hover_current_id != item_id or self.hover_tip_window is None:
            self.hover_current_id = item_id
            self.show_hover_tip(item_id, mouse_x, mouse_y)
        else:
            if self.hover_tip_window:
                self.hover_tip_window.geometry(f"+{mouse_x}+{mouse_y}")

    def on_tree_mouse_leave(self, event):
        self.hide_hover_tip()

    def hide_hover_tip(self):
        if self.hover_tip_window:
            self.hover_tip_window.destroy()
            self.hover_tip_window = None
        self.hover_current_id = None

    def show_hover_tip(self, item_id, x, y):
        if self.hover_tip_window:
            self.hover_tip_window.destroy()

        cdata = self.chart_render_data[item_id]
        vals = self.tree.item(item_id, "values")

        item_name_str = vals[1]
        spec_str = vals[2]
        cpk_str = vals[7]

        w_tip, h_tip = 252, 168
        self.hover_tip_window = tk.Toplevel(self.root)
        self.hover_tip_window.wm_overrideredirect(True)
        self.hover_tip_window.wm_attributes("-topmost", True)
        self.hover_tip_window.geometry(f"{w_tip}x{h_tip}+{x}+{y}")
        self.hover_tip_window.configure(bg="#F0F2F5")

        cv_card = tk.Canvas(self.hover_tip_window, width=w_tip, height=h_tip, bg="#F0F2F5", highlightthickness=0)
        cv_card.pack(fill="both", expand=True)

        self.draw_round_rect(cv_card, 1, 1, w_tip - 2, h_tip - 2, radius=self.corner_r, fill="#FFFFFF", outline="#1565C0", width=1)

        cv_card.create_rectangle(2, 2, w_tip - 2, 24, fill="#E9ECEF", outline="")
        cv_card.create_text(w_tip / 2, 13, text=f"{item_name_str} ({spec_str}) | Cpk: {cpk_str}", 
                            font=("Malgun Gothic", 8, "bold"), fill="#1565C0")

        pad_l, pad_r, pad_t, pad_b = 14, 14, 38, 14
        pw, ph = w_tip - pad_l - pad_r, h_tip - pad_t - pad_b

        counts = cdata["counts"]
        norm_curve = cdata["norm_vals"]
        idx_l, idx_s, idx_u = cdata["idx_l"], cdata["idx_s"], cdata["idx_u"]
        num_bins = len(counts)

        max_val = max(max(counts), max(norm_curve))
        if max_val <= 0: max_val = 1.0
        max_y = max_val * 1.15
        bar_w = pw / num_bins

        for b in range(num_bins):
            x0 = pad_l + b * bar_w
            x1 = x0 + bar_w
            bar_h = (counts[b] / max_y) * ph
            y0 = (pad_t + ph) - bar_h
            y1 = pad_t + ph
            cv_card.create_rectangle(x0, y0, x1, y1, fill="#1976D2", outline="#0D47A1", width=1)

        line_pts = []
        for b in range(num_bins):
            px = pad_l + (b + 0.5) * bar_w
            py = (pad_t + ph) - (norm_curve[b] / max_y) * ph
            line_pts.extend([px, py])
        if len(line_pts) >= 4:
            cv_card.create_line(line_pts, fill="#D32F2F", width=2, smooth=True)

        for idx, lbl, clr in [(idx_l, "LSL", "#D32F2F"), (idx_s, "CTR", "#388E3C"), (idx_u, "USL", "#D32F2F")]:
            xp = pad_l + (idx - 0.5) * bar_w
            cv_card.create_line(xp, pad_t, xp, pad_t + ph, fill=clr, dash=(3, 2), width=1.5)
            cv_card.create_text(xp, pad_t - 8, text=lbl, fill=clr, font=("Malgun Gothic", 7, "bold"))

    @staticmethod
    def _calc_histogram(data_list, num_bins, x_min, x_max):
        counts = [0] * num_bins
        if x_max <= x_min:
            counts[0] = len(data_list)
            return counts
        span = x_max - x_min
        for v in data_list:
            if v < x_min:
                idx = 0
            elif v >= x_max:
                idx = num_bins - 1
            else:
                idx = int((v - x_min) / span * num_bins)
                if idx >= num_bins:
                    idx = num_bins - 1
            counts[idx] += 1
        return counts

    def process_data(self):
        if self.is_processing or self.is_saving or self.is_analyzed:
            return

        self.abort_background_prefetch()

        t = self.texts[self.lang]
        raw_file = self.input_file.get().strip()
        if not raw_file:
            messagebox.showerror("오류", t["err_no_file"])
            return

        file_path = os.path.normpath(os.path.abspath(raw_file))
        if not os.path.exists(file_path):
            messagebox.showerror("오류", "선택한 파일이 존재하지 않습니다.")
            return

        self.is_processing = True
        self.is_save_enabled = False
        self.draw_main_button()
        self.draw_save_button()
        self.dot_count = 0

        send_telemetry("자료 분석", os.path.basename(file_path))

        try:
            self.update_btn_progress(10, "데이터 파일 분석 시작..." if self.lang == "ko" else "Bắt đầu phân tích tệp...")
            self.root.after(500, self.animate_dots)

            self.tot_data.clear()
            self.detail_data.clear()
            self.detail_sample_labels.clear()
            self.detail_sample_coords.clear()
            self.measured_sheets.clear()

            wb = openpyxl.load_workbook(file_path, data_only=True, read_only=True)

            sheets_to_process = []
            for s_name in wb.sheetnames:
                ws = wb[s_name]
                if ws.sheet_state == "visible":
                    low_name = s_name.strip().lower()
                    if ("sample_a" not in low_name) and ("도면" not in low_name) and ("summary" not in low_name):
                        sheets_to_process.append(s_name)

            has_valid_data = False
            for s_name in sheets_to_process:
                ws = wb[s_name]
                for r in range(5, 8):
                    for c in range(19, 22):
                        v = ws.cell(row=r, column=c).value
                        if v is not None and str(v).strip() not in ("", "None"):
                            has_valid_data = True
                            break
                    if has_valid_data: break
                if has_valid_data: break

            if not has_valid_data:
                wb.close()
                messagebox.showwarning("알림", t["err_no_data"])
                self.finish_btn_progress("분석 실패: 치수 data 없음")
                return

            self.update_btn_progress(35, "측정 데이터 파싱 및 로드 중..." if self.lang == "ko" else "Đang phân tích và tải dữ liệu...")

            for s_name in sheets_to_process:
                ws = wb[s_name]
                all_rows = list(ws.iter_rows(values_only=True))
                if not all_rows or len(all_rows) < 2:
                    continue

                head_row = -1
                col_name, col_draw, col_date, col_mold, col_cav = -1, -1, -1, -1, -1

                for r in range(min(12, len(all_rows))):
                    row_vals = [str(x).upper() if x is not None else "" for x in all_rows[r]]
                    for c_idx, val in enumerate(row_vals):
                        if "MEASURE" in val and col_name == -1: head_row = r; col_name = c_idx
                        if ("DRAWING" in val or "도면" in val) and col_draw == -1: col_draw = c_idx
                        if ("DATE" in val or "일자" in val) and col_date == -1: col_date = c_idx
                        if ("MOLD" in val or "금형" in val) and col_mold == -1: col_mold = c_idx
                        if ("CAV" in val or "캐비" in val) and col_cav == -1: col_cav = c_idx
                    if head_row != -1: break

                if head_row == -1:
                    continue

                num_cols = len(all_rows[0])
                if col_date == -1: col_date = 6
                if col_mold == -1: col_mold = col_date + 1 if num_cols > col_date + 1 else -1
                if col_cav == -1: col_cav = col_mold + 1 if col_mold != -1 and num_cols > col_mold + 1 else -1

                col_spec, col_utol, col_ltol = col_name + 1, col_name + 2, col_name + 3
                col_data_start = col_name + 4
                col_data_end = col_data_start + 9

                sample_col_labels = {}
                row2_idx, row3_idx = 2, 3
                last_sec_title = ""
                max_check_cols = min(num_cols, max(col_data_end + 15, 55))
                
                for c in range(col_data_start, max_check_cols):
                    v_top = ""
                    if len(all_rows) > row2_idx and c < len(all_rows[row2_idx]) and all_rows[row2_idx][c] is not None:
                        v_top = str(all_rows[row2_idx][c]).strip()
                    if v_top and v_top != "None":
                        last_sec_title = v_top

                    v_sub = ""
                    if len(all_rows) > row3_idx and c < len(all_rows[row3_idx]) and all_rows[row3_idx][c] is not None:
                        v_sub = str(all_rows[row3_idx][c]).strip()
                    
                    if not v_sub or v_sub == "None":
                        v_sub = f"#{c - col_data_start + 1}"

                    prefix = f"[{last_sec_title}] " if last_sec_title else ""
                    sample_col_labels[c] = f"{prefix}{v_sub}"

                proc_name = str(all_rows[head_row + 1][0]).strip() if all_rows[head_row + 1][0] is not None else ""
                if not proc_name or proc_name == "None":
                    proc_name = s_name

                last_date, last_mold, last_cav = "-", "1", "1"
                sheet_has_measure = False

                for r in range(head_row + 1, len(all_rows)):
                    row_data = all_rows[r]
                    if col_date < len(row_data) and row_data[col_date] is not None:
                        d_val = str(row_data[col_date]).strip()
                        if d_val and d_val != "None":
                            last_date = d_val.split(" ")[0].replace(".", "-").replace("/", "-")
                    cur_date = last_date

                    if col_mold != -1 and col_mold < len(row_data) and row_data[col_mold] is not None:
                        m_val = str(row_data[col_mold]).strip()
                        if m_val and m_val != "None":
                            last_mold = m_val
                    cur_mold = last_mold

                    if col_cav != -1 and col_cav < len(row_data) and row_data[col_cav] is not None:
                        c_val = str(row_data[col_cav]).strip()
                        if c_val and c_val != "None":
                            last_cav = c_val
                    cur_cav = last_cav

                    if col_name >= len(row_data) or row_data[col_name] is None:
                        continue
                    raw_m_name = str(row_data[col_name]).strip()
                    if not raw_m_name or raw_m_name in ("None", "MEASURE", "DRAWING"):
                        continue

                    draw_no_str = ""
                    if col_draw != -1 and col_draw < len(row_data) and row_data[col_draw] is not None:
                        raw_draw_val = row_data[col_draw]
                        d_cand = str(raw_draw_val).strip()
                        try:
                            f_c = float(d_cand)
                            if f_c.is_integer(): d_cand = str(int(f_c))
                        except Exception: pass
                        if d_cand and d_cand != "None":
                            draw_no_str = d_cand

                    m_name = f"{raw_m_name} ({draw_no_str})" if draw_no_str else raw_m_name

                    try:
                        spec = float(row_data[col_spec])
                        utol = float(row_data[col_utol])
                        ltol = float(row_data[col_ltol])
                    except Exception:
                        continue

                    vals = []
                    val_labels = []
                    val_coords = []
                    for c in range(col_data_start, min(col_data_end, len(row_data))):
                        val_cell = row_data[c]
                        if val_cell is not None:
                            try:
                                f_val = float(val_cell)
                                vals.append(f_val)
                                val_labels.append(sample_col_labels.get(c, f"#{len(vals)}"))
                                col_ltr = get_column_letter(c + 1)
                                val_coords.append(f"{col_ltr}{r + 1}")
                            except Exception:
                                pass

                    if not vals:
                        continue

                    sheet_has_measure = True
                    key_tot = (s_name, proc_name, m_name, spec, utol, ltol)
                    if key_tot not in self.tot_data: self.tot_data[key_tot] = []
                    self.tot_data[key_tot].extend(vals)

                    key_detail = (s_name, proc_name, cur_date, cur_mold, cur_cav, m_name, spec, utol, ltol)
                    if key_detail not in self.detail_data:
                        self.detail_data[key_detail] = []
                        self.detail_sample_labels[key_detail] = []
                        self.detail_sample_coords[key_detail] = []
                    self.detail_data[key_detail].extend(vals)
                    self.detail_sample_labels[key_detail].extend(val_labels)
                    self.detail_sample_coords[key_detail].extend(val_coords)

                if sheet_has_measure and s_name not in self.measured_sheets:
                    self.measured_sheets.append(s_name)

            wb.close()

            if not self.tot_data:
                messagebox.showwarning("알림", t["notice_no_meas"])
                self.finish_btn_progress("분석 실패: 유효 데이터 없음" if self.lang == "ko" else "Thất bại: Không có dữ liệu")
                return

            self.update_btn_progress(60, "데이터 정합성 및 허위 입력 검출 중..." if self.lang == "ko" else "Đang kiểm tra tính trung thực...")
            self.analyze_data_integrity()

            self.update_btn_progress(80, "통계 및 공정능력(Cpk) 연산 중..." if self.lang == "ko" else "Đang tính toán thống kê và Cpk...")

            self.refresh_treeview_rows()
            self.rebuild_chart_render_data()
            self.autofit_treeview_columns()

            self.update_btn_progress(100, t["status_done_guide"])
            self.is_analyzed = True
            self.is_save_enabled = True
            self.draw_save_button()
            self.root.after(800, lambda: self.finish_btn_progress(t["status_done_guide"]))

            self.start_background_prefetch()

        except Exception as e:
            self.finish_btn_progress("오류 발생")
            messagebox.showerror("오류 발생", f"분석 중 오류가 발생했습니다:\n{str(e)}")

    def start_background_prefetch(self):
        self.abort_background_prefetch()
        self.bg_abort_flag.clear()
        
        tot_snapshot = dict(self.tot_data)
        detail_snapshot = dict(self.detail_data)
        lang_snap = self.lang

        self.bg_thread = threading.Thread(
            target=self._bg_prefetch_worker,
            args=(tot_snapshot, detail_snapshot, lang_snap),
            daemon=True
        )
        self.bg_thread.start()

    def _bg_prefetch_worker(self, tot_data, detail_data, lang):
        pythoncom.CoInitialize()
        enable_com_retry_filter()

        tmp_file = os.path.normpath(os.path.abspath(f"~tmp_qc_report_{int(time.time()*1000)}.xlsx"))
        excel = None
        wb = None
        local_pid = None
        success = False

        try:
            time.sleep(1.0)
            if self.bg_abort_flag.is_set(): return

            def safe_exec(target_func, *args, **kwargs):
                for _ in range(15):
                    if self.bg_abort_flag.is_set(): raise InterruptedError()
                    try:
                        return target_func(*args, **kwargs)
                    except InterruptedError:
                        raise
                    except Exception as ex:
                        err_msg = str(ex)
                        if "-2147418111" in err_msg or "RPC_E_CALL_REJECTED" in err_msg or "-2147023170" in err_msg:
                            time.sleep(0.2)
                        else:
                            raise ex
                return target_func(*args, **kwargs)

            excel = safe_exec(win32.DispatchEx, "Excel.Application")
            local_pid = get_excel_pid(excel)
            with self.bg_lock:
                self.bg_excel_pid = local_pid

            excel.Visible = False
            excel.ScreenUpdating = False
            excel.DisplayAlerts = False
            excel.Interactive = False

            wb = safe_exec(excel.Workbooks.Add)
            self._write_report_content(wb, excel, tot_data, detail_data, lang, safe_exec, is_bg=True)
            
            if self.bg_abort_flag.is_set(): raise InterruptedError()

            if os.path.exists(tmp_file):
                try: os.remove(tmp_file)
                except Exception: pass

            safe_exec(wb.SaveAs, tmp_file, 51)
            wb.Saved = True
            safe_exec(wb.Close, False)
            wb = None
            success = True

        except (InterruptedError, Exception):
            success = False
        finally:
            disable_com_retry_filter()
            if excel:
                try:
                    excel.DisplayAlerts = False
                    excel.Interactive = True
                    excel.Quit()
                except Exception: pass
                del excel
            try: pythoncom.CoUninitialize()
            except Exception: pass
            gc.collect()

            if local_pid:
                kill_process_by_pid(local_pid)
                with self.bg_lock:
                    if self.bg_excel_pid == local_pid:
                        self.bg_excel_pid = None

        with self.bg_lock:
            if success and not self.bg_abort_flag.is_set():
                self.bg_temp_file = tmp_file
                self.bg_ready = True
            else:
                if os.path.exists(tmp_file):
                    try: os.remove(tmp_file)
                    except Exception: pass

    def show_centered_complete_popup(self):
        pop_w, pop_h = 240, 120
        self.root.update_idletasks()
        rx, ry = self.root.winfo_rootx(), self.root.winfo_rooty()
        rw, rh = self.root.winfo_width(), self.root.winfo_height()
        
        px, py = rx + (rw - pop_w) // 2, ry + (rh - pop_h) // 2

        pop = tk.Toplevel(self.root)
        pop.title("알림" if self.lang == "ko" else "Thông báo")
        pop.geometry(f"{pop_w}x{pop_h}+{px}+{py}")
        pop.resizable(False, False)
        pop.configure(bg="#FFFFFF")
        pop.transient(self.root)
        pop.grab_set()

        t = self.texts[self.lang]
        lbl = tk.Label(pop, text=t["save_done"], font=("Malgun Gothic", 11, "bold"), fg="#1565C0", bg="#FFFFFF")
        lbl.pack(expand=True, pady=(20, 10))

        btn = tk.Button(pop, text=t["btn_confirm"], font=("Malgun Gothic", 9, "bold"), bg="#1976D2", fg="white", 
                        activebackground="#1565C0", activeforeground="white", width=8, relief="flat", cursor="hand2",
                        command=pop.destroy)
        btn.pack(pady=(0, 15))

    def save_excel_report(self):
        if not self.tot_data:
            messagebox.showwarning("알림", "저장할 분석 결과가 없습니다. 먼저 분석을 실행하세요.")
            return

        raw_file = self.input_file.get().strip()
        file_path = os.path.normpath(os.path.abspath(raw_file))
        
        out_dir = self.output_dir.get().strip() or os.path.dirname(file_path)
        out_dir = os.path.normpath(os.path.abspath(out_dir))

        base_name = os.path.splitext(os.path.basename(file_path))[0]
        candidate_path = os.path.join(out_dir, f"Summary_Report_{base_name}.xlsx")
        out_file_path = os.path.normpath(candidate_path)

        if os.path.exists(out_file_path):
            try:
                with open(out_file_path, "a"):
                    pass
            except PermissionError:
                msg = ("기존 보고서 파일이 열려 있어 저장할 수 없습니다.\n"
                       "엑셀 창을 닫고 다시 시도하거나, 시간 태그를 붙여 새로 저장할까요?")
                if not messagebox.askyesno("파일 열림 안내", msg):
                    return
                ts = datetime.datetime.now().strftime("%H%M%S")
                out_file_path = os.path.normpath(os.path.join(out_dir, f"Summary_Report_{base_name}_{ts}.xlsx"))
            else:
                overwrite_msg = ("이미 동일한 보고서 파일이 존재합니다.\n덮어쓰시겠습니까?\n\n"
                                 f"파일: {os.path.basename(out_file_path)}")
                if not messagebox.askyesno("덮어쓰기 확인", overwrite_msg):
                    return

        self.is_saving = True
        self.is_save_enabled = False
        self.update_save_progress(0, "엑셀 보고서 생성 준비 중...")
        self.animate_saving_color()

        with self.bg_lock:
            ready = self.bg_ready
            tmp_f = self.bg_temp_file

        if ready and tmp_f and os.path.exists(tmp_f):
            try:
                self.update_save_progress(50, "사전 생성된 보고서로 즉각 복제 및 완료 처리 중...")
                if os.path.exists(out_file_path):
                    try: os.remove(out_file_path)
                    except Exception: pass
                import shutil
                shutil.copy2(tmp_f, out_file_path)
                
                try: os.remove(tmp_f)
                except Exception: pass
                self.bg_temp_file = None
                self.bg_ready = False

                self.update_save_progress(100, f"보고서 저장 완료: {os.path.basename(out_file_path)}")
                send_telemetry("파일저장", os.path.basename(out_file_path))
                
                self.is_saving = False
                self.is_save_enabled = False
                self.draw_save_button()
                self.show_centered_complete_popup()
                return
            except Exception:
                pass

        try:
            self.abort_background_prefetch()
            self.build_excel_report(out_file_path, self.tot_data, self.detail_data)
            send_telemetry("파일저장", os.path.basename(out_file_path))
            self.update_save_progress(100, f"보고서 저장 완료: {os.path.basename(out_file_path)}")
            
            self.is_saving = False
            self.is_save_enabled = False
            self.draw_save_button()
            
            self.show_centered_complete_popup()
        except Exception as e:
            self.is_saving = False
            self.is_save_enabled = True
            self.draw_save_button()
            self.lbl_status.config(text="보고서 저장 실패" if self.lang == "ko" else "Lưu báo cáo thất bại")
            messagebox.showerror("저장 오류", f"엑셀 보고서 생성 중 오류가 발생했습니다:\n{str(e)}")

    def _write_report_content(self, wb, excel, tot_data, detail_data, lang, safe_exec, is_bg=False):
        ws_rpt = wb.Sheets(1)
        ws_rpt.Name = "Summary_Report"
        ws_data = wb.Sheets.Add(After=ws_rpt)
        ws_data.Name = "ChartData"
        ws_data.Visible = False

        ws_rpt.Cells.Font.Size = 10
        ws_rpt.Cells.Font.Name = "Malgun Gothic"

        ws_rpt.Columns("A").ColumnWidth = 1
        ws_rpt.Rows(1).RowHeight = 9

        RGB_GRAY = 14277081
        RGB_LIGHT_BLUE = 16445670
        RGB_RED_BG = 14342136
        RGB_RED_FONT = 2364530
        RGB_YEL_BG = 13497343
        RGB_YEL_FONT = 290885
        RGB_GRN_BG = 14351828
        RGB_GRN_FONT = 2381333
        RGB_30PCT_GRAY = 11513775
        RGB_SUSPECT_BG = 16445179
        RGB_SUSPECT_FONT = 7291497

        t = self.texts[lang]
        n_t1 = max(1, len(tot_data))
        n_t2 = max(1, len(detail_data))

        if not is_bg:
            self.update_save_progress(2, "표 1(종합 요약) 서식 초기화 중...")

        ws_rpt.Cells(2, 2).Value = t["excel_t1_title"]
        ws_rpt.Cells(2, 2).Font.Bold = True
        ws_rpt.Cells(2, 2).Font.Size = 10
        ws_rpt.Range("B2:O2").Merge()
        ws_rpt.Range("B2:O2").HorizontalAlignment = -4131

        ws_rpt.Rows(3).RowHeight = 22.5
        ws_rpt.Range("C3:E3").Merge()
        
        for pos, h in t["excel_t1_headers"]:
            if h: ws_rpt.Range(pos).Value = h

        hdr_rng = ws_rpt.Range("B3:O3")
        hdr_rng.Font.Bold = True
        hdr_rng.Font.Size = 10
        hdr_rng.HorizontalAlignment = -4108
        hdr_rng.VerticalAlignment = -4108
        hdr_rng.Interior.Color = RGB_GRAY

        rpt_row = 4
        t1_start = 4
        num_bins = 15
        p_arr1, idx_list = [], []

        for i, ((sheet, proc, item, spec, utol, ltol), vals) in enumerate(tot_data.items()):
            if is_bg and self.bg_abort_flag.is_set(): raise InterruptedError()
            if is_bg: time.sleep(0.04)

            t_key = (sheet, proc, item, spec, utol, ltol)
            p_arr1.append(proc)
            st = self.compute_stats(vals, spec, utol, ltol, lang)

            ws_rpt.Rows(rpt_row).RowHeight = 60
            
            ws_rpt.Cells(rpt_row, 2).Value = proc
            ws_rpt.Range(ws_rpt.Cells(rpt_row, 3), ws_rpt.Cells(rpt_row, 5)).Merge()

            display_item = translate_measure_name(item, lang)
            ws_rpt.Cells(rpt_row, 6).Value = display_item
            
            cell_g = ws_rpt.Cells(rpt_row, 7)
            cell_g.Value = f"{spec:.2f}\n(±{utol:.2f})"
            cell_g.WrapText = True

            ws_rpt.Cells(rpt_row, 8).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 8).Value = st["mean"]
            ws_rpt.Cells(rpt_row, 9).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 9).Value = st["min"]
            ws_rpt.Cells(rpt_row, 10).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 10).Value = st["max"]

            cell_k = ws_rpt.Cells(rpt_row, 11)
            cell_k.NumberFormat = "@"; cell_k.Value = f"{st['out_c']}/{st['n']}"
            if st["out_c"] > 0:
                cell_k.Interior.Color = RGB_RED_BG; cell_k.Font.Color = RGB_RED_FONT; cell_k.Font.Bold = True

            cell_l = ws_rpt.Cells(rpt_row, 12)
            cell_l.NumberFormat = "0.00"; cell_l.Value = st["cpk"]
            if st["cpk"] < 1.0:
                cell_l.Interior.Color = RGB_RED_BG; cell_l.Font.Color = RGB_RED_FONT; cell_l.Font.Bold = True
            elif st["cpk"] <= 1.05:
                cell_l.Interior.Color = RGB_YEL_BG; cell_l.Font.Color = RGB_YEL_FONT; cell_l.Font.Bold = True

            cell_m = ws_rpt.Cells(rpt_row, 13)
            cell_m.NumberFormat = "@"; cell_m.Value = st["near_s"]
            if st["near_s"] not in ("없음", "Không"):
                cell_m.Interior.Color = RGB_YEL_BG; cell_m.Font.Color = RGB_YEL_FONT; cell_m.Font.Bold = True

            cell_n = ws_rpt.Cells(rpt_row, 14)
            cell_n.Value = st["judge"]; cell_n.Font.Bold = True
            if st["judge"] == "OK" and len(st["issues"]) > 0:
                cell_n.Interior.Color = RGB_YEL_BG; cell_n.Font.Color = RGB_YEL_FONT
            elif st["judge"] == "OK":
                cell_n.Interior.Color = RGB_GRN_BG; cell_n.Font.Color = RGB_GRN_FONT
            elif st["judge"] in ("경고", "Cảnh báo"):
                cell_n.Interior.Color = RGB_YEL_BG; cell_n.Font.Color = RGB_YEL_FONT
            else:
                cell_n.Interior.Color = RGB_RED_BG; cell_n.Font.Color = RGB_RED_FONT

            suspect_info = self.integrity_tot.get(t_key, None)
            suspect_reasons = []
            if suspect_info:
                suspect_reasons.append(t["suspect_label"])
            combined_issues = st["issues"] + suspect_reasons

            cell_o = ws_rpt.Cells(rpt_row, 15)
            cell_o.Font.Size = 9
            cell_o.Value = "\n".join(combined_issues)
            cell_o.WrapText = True
            cell_o.HorizontalAlignment = -4131
            
            if suspect_reasons:
                cell_o.Interior.Color = RGB_SUSPECT_BG
                cell_o.Font.Color = RGB_SUSPECT_FONT
                cell_o.Font.Bold = True
            elif st["judge"] == "NG":
                cell_o.Font.Color = RGB_RED_FONT
                cell_o.Font.Bold = True

            mid_rng = ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 14))
            mid_rng.HorizontalAlignment = -4108
            mid_rng.VerticalAlignment = -4108

            chart_col = i * 3 + 1
            x_min = min(st["min"], st["lsl"]) - (0.5 * st["std"])
            x_max = max(st["max"], st["usl"]) + (0.5 * st["std"])
            bin_w = (x_max - x_min) / num_bins
            if bin_w <= 0: bin_w = 0.001

            bin_centers = [x_min + (b + 0.5) * bin_w for b in range(num_bins)]
            counts = self._calc_histogram(st["arr"], num_bins, x_min, x_max)
            norm_vals = [(1 / (st["std"] * math.sqrt(2 * math.pi))) * math.exp(-0.5 * ((bc - st["mean"]) / st["std"]) ** 2) * st["n"] * bin_w for bc in bin_centers]

            diff_l = [abs(bc - st["lsl"]) for bc in bin_centers]
            diff_s = [abs(bc - spec) for bc in bin_centers]
            diff_u = [abs(bc - st["usl"]) for bc in bin_centers]
            idx_list.append((diff_l.index(min(diff_l)) + 1, diff_s.index(min(diff_s)) + 1, diff_u.index(min(diff_u)) + 1))

            c_block = [["BinLabel", "Histogram", "NormalCurve"]]
            for b_idx in range(num_bins):
                c_block.append(["", int(counts[b_idx]), float(norm_vals[b_idx])])
            ws_data.Range(ws_data.Cells(1, chart_col), ws_data.Cells(num_bins + 1, chart_col + 2)).Value = c_block

            rpt_row += 1
            if not is_bg:
                pct_val = 2 + int(13 * (i + 1) / n_t1)
                self.update_save_progress(pct_val, f"표 1 데이터 작성 중... ({i+1}/{n_t1})")

        t1_end = rpt_row - 1

        excel.DisplayAlerts = False
        m_start = 0
        for i in range(1, len(p_arr1) + 1):
            if i == len(p_arr1) or p_arr1[i] != p_arr1[m_start]:
                if (i - 1) > m_start:
                    safe_exec(ws_rpt.Range(ws_rpt.Cells(t1_start + m_start, 2), ws_rpt.Cells(t1_start + i - 1, 2)).Merge)
                m_start = i
        excel.DisplayAlerts = True

        tbl1_rng = ws_rpt.Range(ws_rpt.Cells(3, 2), ws_rpt.Cells(t1_end, 15))
        for border_id in [7, 8, 9, 10, 11]:
            tbl1_rng.Borders(border_id).LineStyle = 1
        for r in range(t1_start, t1_end):
            i = r - t1_start
            if i < len(p_arr1) - 1:
                line_style = 1 if p_arr1[i] != p_arr1[i + 1] else -4118
                target_c = 2 if p_arr1[i] != p_arr1[i + 1] else 6
                ws_rpt.Range(ws_rpt.Cells(r, target_c), ws_rpt.Cells(r, 15)).Borders(9).LineStyle = line_style

        ws_rpt.Columns("B").ColumnWidth = 11
        ws_rpt.Columns("C").ColumnWidth = 8
        ws_rpt.Columns("D").ColumnWidth = 8
        ws_rpt.Columns("E").ColumnWidth = 8
        ws_rpt.Columns("F").AutoFit()
        ws_rpt.Columns("G").ColumnWidth = 10.5
        ws_rpt.Range("H:M").ColumnWidth = 7.5
        ws_rpt.Columns("N").ColumnWidth = 10
        ws_rpt.Columns("O").ColumnWidth = 30

        for i in range(len(p_arr1)):
            if is_bg and self.bg_abort_flag.is_set(): raise InterruptedError()
            time.sleep(0.04 if is_bg else 0.02)
            r = t1_start + i
            cell_target = ws_rpt.Range(ws_rpt.Cells(r, 3), ws_rpt.Cells(r, 5))
            chart_col = i * 3 + 1
            idx_l, idx_s, idx_u = idx_list[i]

            cho = safe_exec(ws_rpt.ChartObjects().Add, cell_target.Left + 1, cell_target.Top + 1, cell_target.Width - 2, 58)
            cho.Placement = 1
            chart = cho.Chart
            chart.ChartType = 51
            chart_src = ws_data.Range(ws_data.Cells(1, chart_col), ws_data.Cells(num_bins + 1, chart_col + 2))
            safe_exec(chart.SetSourceData, chart_src)
            chart.HasTitle = False
            chart.HasLegend = False

            for ax_id in (2, 1):
                try:
                    ax = chart.Axes(ax_id)
                    if ax_id == 2:
                        ax.MinimumScale = 0
                        ax.CrossesAt = 0
                        ax.HasMajorGridlines = False
                    ax.TickLabelPosition = -4142
                    ax.MajorTickMark = -4142
                    ax.Border.LineStyle = -4142
                except Exception: pass

            s1 = chart.SeriesCollection(1)
            s1.Format.Fill.ForeColor.RGB = 12157001
            s1.Format.Line.ForeColor.RGB = 7224340
            s1.Format.Line.Weight = 0.5
            chart.ChartGroups(1).GapWidth = 0

            s2 = chart.SeriesCollection(2)
            s2.ChartType = 4
            s2.Format.Line.ForeColor.RGB = 2305495
            s2.Format.Line.Weight = 1.75
            s2.MarkerStyle = -4142
            s2.Smooth = True
            chart.ChartArea.Format.Line.Visible = 0

            try:
                chart.PlotArea.Left = 2
                chart.PlotArea.Top = 10
                chart.PlotArea.Width = cho.Width - 4
                chart.PlotArea.Height = 46
            except Exception: pass

            pa_l, pa_t, pa_w, pa_h = 2, 10, cho.Width - 4, 46

            for idx, text, color in [(idx_l, "LSL", 2305495), (idx_s, "CENTER", 6336039), (idx_u, "USL", 2305495)]:
                xp = pa_l + (idx - 0.5) * (pa_w / num_bins)
                ln = chart.Shapes.AddLine(xp, pa_t, xp, pa_t + pa_h)
                ln.Line.ForeColor.RGB = color; ln.Line.DashStyle = 4
                lbl_x = max(0, min(cho.Width - 26, xp - 12)) if text != "CENTER" else max(0, xp - 18)
                lbl_w = 26 if text != "CENTER" else 38
                lbl = chart.Shapes.AddLabel(1, lbl_x, 0, lbl_w, 11)
                lbl.TextFrame.Characters().Text = text
                lbl.TextFrame.Characters().Font.Size = 6.5
                lbl.TextFrame.Characters().Font.Bold = True
                lbl.TextFrame.Characters().Font.Color = color

            del s1, s2, chart, cho

            if not is_bg:
                chart_pct = 15 + int(40 * (i + 1) / n_t1)
                self.update_save_progress(chart_pct, f"도수분포도 생성 중... ({i+1}/{n_t1})")

        rpt_row += 2
        ws_rpt.Cells(rpt_row, 2).Value = t["excel_t2_title"]
        ws_rpt.Cells(rpt_row, 2).Font.Bold = True
        ws_rpt.Cells(rpt_row, 2).Font.Size = 10
        ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 16)).Merge()
        ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 16)).HorizontalAlignment = -4131

        rpt_row += 1
        t2_hdr_row = rpt_row
        ws_rpt.Rows(t2_hdr_row).RowHeight = 22.5

        for c_idx, h in enumerate(t["excel_t2_headers"]):
            cell_h = ws_rpt.Cells(rpt_row, c_idx + 2)
            cell_h.Value = h
            cell_h.Font.Bold = True
            cell_h.Font.Size = 10
            cell_h.HorizontalAlignment = -4108
            cell_h.VerticalAlignment = -4160
            cell_h.Interior.Color = RGB_LIGHT_BLUE

        hdr2_rng = ws_rpt.Range(ws_rpt.Cells(t2_hdr_row, 2), ws_rpt.Cells(t2_hdr_row, 16))
        for bid in [7, 8, 9, 10, 11]:
            hdr2_rng.Borders(bid).LineStyle = 1

        t2_start = rpt_row + 1
        detail_keys = list(detail_data.keys())
        prev_set_key = None

        for idx_d, (sheet, proc, d_str, mold_str, cav_str, item, spec, utol, ltol) in enumerate(detail_keys):
            if is_bg and self.bg_abort_flag.is_set(): raise InterruptedError()
            if is_bg: time.sleep(0.03)

            d_key = (sheet, proc, d_str, mold_str, cav_str, item, spec, utol, ltol)
            vals = detail_data[d_key]
            rpt_row += 1
            ws_rpt.Rows(rpt_row).RowHeight = 22
            st = self.compute_stats(vals, spec, utol, ltol, lang)

            cur_set_key = (sheet, proc, d_str, mold_str, cav_str)
            is_first_of_set = (cur_set_key != prev_set_key)
            prev_set_key = cur_set_key

            cell_sheet_div = ws_rpt.Cells(rpt_row, 2)
            cell_sheet_div.NumberFormat = "@"; cell_sheet_div.Value = str(sheet)
            cell_date = ws_rpt.Cells(rpt_row, 3)
            cell_date.NumberFormat = "@"; cell_date.Value = str(d_str)
            cell_mold = ws_rpt.Cells(rpt_row, 4)
            cell_mold.NumberFormat = "@"; cell_mold.Value = str(mold_str)
            cell_cav = ws_rpt.Cells(rpt_row, 5)
            cell_cav.NumberFormat = "@"; cell_cav.Value = str(cav_str)

            text_color = 0 if is_first_of_set else RGB_30PCT_GRAY
            for c_target in [cell_sheet_div, cell_date, cell_mold, cell_cav]:
                c_target.Font.Color = text_color

            display_item_d = translate_measure_name(item, lang)
            ws_rpt.Cells(rpt_row, 6).Value = display_item_d
            ws_rpt.Cells(rpt_row, 7).Value = f"{spec:.2f}±{utol:.2f}"

            ws_rpt.Cells(rpt_row, 8).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 8).Value = st["mean"]
            ws_rpt.Cells(rpt_row, 9).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 9).Value = st["min"]
            ws_rpt.Cells(rpt_row, 10).NumberFormat = "0.00"; ws_rpt.Cells(rpt_row, 10).Value = st["max"]

            cell_k2 = ws_rpt.Cells(rpt_row, 11)
            cell_k2.NumberFormat = "@"; cell_k2.Value = f"{st['out_c']}/{st['n']}"
            if st["out_c"] > 0:
                cell_k2.Interior.Color = RGB_RED_BG; cell_k2.Font.Color = RGB_RED_FONT; cell_k2.Font.Bold = True

            cell_l2 = ws_rpt.Cells(rpt_row, 12)
            cell_l2.NumberFormat = "0.00"; cell_l2.Value = st["cpk"]
            if st["cpk"] < 1.0:
                cell_l2.Interior.Color = RGB_RED_BG; cell_l2.Font.Color = RGB_RED_FONT; cell_l2.Font.Bold = True
            elif st["cpk"] <= 1.05:
                cell_l2.Interior.Color = RGB_YEL_BG; cell_l2.Font.Color = RGB_YEL_FONT; cell_l2.Font.Bold = True

            cell_m2 = ws_rpt.Cells(rpt_row, 13)
            cell_m2.NumberFormat = "@"; cell_m2.Value = st["near_s"]
            if st["near_s"] not in ("없음", "Không"):
                cell_m2.Interior.Color = RGB_YEL_BG; cell_m2.Font.Color = RGB_YEL_FONT; cell_m2.Font.Bold = True

            cell_n2 = ws_rpt.Cells(rpt_row, 14)
            cell_n2.Value = st["judge"]; cell_n2.Font.Bold = True
            if st["judge"] == "OK" and len(st["issues"]) > 0:
                cell_n2.Interior.Color = RGB_YEL_BG; cell_n2.Font.Color = RGB_YEL_FONT
            elif st["judge"] == "OK":
                cell_n2.Interior.Color = RGB_GRN_BG; cell_n2.Font.Color = RGB_GRN_FONT
            elif st["judge"] in ("경고", "Cảnh báo"):
                cell_n2.Interior.Color = RGB_YEL_BG; cell_n2.Font.Color = RGB_YEL_FONT
            else:
                cell_n2.Interior.Color = RGB_RED_BG; cell_n2.Font.Color = RGB_RED_FONT

            suspect_info_d = self.integrity_detail.get(d_key, None)
            suspect_reasons_d = []
            if suspect_info_d:
                suspect_reasons_d.append(t["suspect_label"])
            combined_issues_d = st["issues"] + suspect_reasons_d

            cell_o2 = ws_rpt.Cells(rpt_row, 15)
            cell_o2.Font.Size = 9
            cell_o2.Value = "\n".join(combined_issues_d)
            cell_o2.WrapText = True
            cell_o2.HorizontalAlignment = -4131
            
            if suspect_reasons_d:
                cell_o2.Interior.Color = RGB_SUSPECT_BG
                cell_o2.Font.Color = RGB_SUSPECT_FONT
                cell_o2.Font.Bold = True
            elif st["judge"] == "NG":
                cell_o2.Font.Color = RGB_RED_FONT
                cell_o2.Font.Bold = True

            cell_p2 = ws_rpt.Cells(rpt_row, 16)
            cell_p2.Font.Size = 8.5
            cell_p2.Value = suspect_info_d["evidence"] if suspect_info_d else "-"
            cell_p2.WrapText = True
            cell_p2.HorizontalAlignment = -4131
            if suspect_info_d:
                cell_p2.Interior.Color = RGB_SUSPECT_BG
                cell_p2.Font.Color = RGB_SUSPECT_FONT

            ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 14)).HorizontalAlignment = -4108
            ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 14)).VerticalAlignment = -4108

            row_rng = ws_rpt.Range(ws_rpt.Cells(rpt_row, 2), ws_rpt.Cells(rpt_row, 16))
            for bid in [7, 10, 11]: row_rng.Borders(bid).LineStyle = 1
            
            if idx_d == len(detail_keys) - 1:
                row_rng.Borders(9).LineStyle = 1
            else:
                next_set_key = detail_keys[idx_d + 1][:5]
                row_rng.Borders(9).LineStyle = -4118 if cur_set_key == next_set_key else 1

            if not is_bg:
                detail_pct = 55 + int(40 * (idx_d + 1) / n_t2)
                self.update_save_progress(detail_pct, f"세부 데이터 작성 중... ({idx_d+1}/{n_t2})")

        t2_end = rpt_row

        tbl2_rng = ws_rpt.Range(ws_rpt.Cells(t2_hdr_row, 2), ws_rpt.Cells(t2_end, 16))
        try:
            ws_rpt.AutoFilterMode = False
            tbl2_rng.AutoFilter(Field=1)
        except Exception: pass

        ws_rpt.Columns("B").ColumnWidth = 12
        ws_rpt.Columns("C").ColumnWidth = 12
        ws_rpt.Columns("D").ColumnWidth = 8
        ws_rpt.Columns("E").ColumnWidth = 8
        ws_rpt.Columns("F").AutoFit()
        ws_rpt.Columns("G").ColumnWidth = 10.5
        ws_rpt.Range("H:L").ColumnWidth = 7.5
        ws_rpt.Columns("M").ColumnWidth = 12
        ws_rpt.Columns("N").ColumnWidth = 8
        ws_rpt.Columns("O").ColumnWidth = 30
        ws_rpt.Columns("P").ColumnWidth = 34

        try:
            ws_rpt.Activate()
            ws_rpt.Range("G1").Select()
            excel.ActiveWindow.FreezePanes = True
        except Exception:
            pass

    def build_excel_report(self, out_file, tot_data, detail_data):
        pythoncom.CoInitialize()
        enable_com_retry_filter()

        def safe_exec(target_func, *args, **kwargs):
            for retry in range(20):
                try:
                    return target_func(*args, **kwargs)
                except Exception as ex:
                    err_msg = str(ex)
                    if "-2147418111" in err_msg or "RPC_E_CALL_REJECTED" in err_msg or "-2147023170" in err_msg:
                        time.sleep(0.15)
                    else:
                        raise ex
            return target_func(*args, **kwargs)

        excel = None
        wb = None
        local_pid = None
        try:
            excel = safe_exec(win32.DispatchEx, "Excel.Application")
            local_pid = get_excel_pid(excel)
            excel.Visible = False
            excel.ScreenUpdating = False
            excel.DisplayAlerts = False
            excel.Interactive = False

            try:
                excel.Application.AutomationSecurity = 3
            except Exception:
                pass

            wb = safe_exec(excel.Workbooks.Add)
            self._write_report_content(wb, excel, tot_data, detail_data, self.lang, safe_exec, is_bg=False)

            self.update_save_progress(97, "엑셀 파일 저장 및 프로세스 정리 중...")

            safe_save_path = os.path.normpath(os.path.abspath(out_file))
            if os.path.exists(safe_save_path):
                try: os.remove(safe_save_path)
                except Exception: pass

            safe_exec(wb.SaveAs, safe_save_path, 51)
            wb.Saved = True
            safe_exec(wb.Close, False)
            wb = None

        finally:
            disable_com_retry_filter()
            if excel:
                try:
                    excel.DisplayAlerts = False
                    excel.Interactive = True
                    excel.Quit()
                except Exception:
                    pass
                del excel
            
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass
            gc.collect()

            if local_pid:
                kill_process_by_pid(local_pid)

# ==========================================
# Windows 시스템 전역 Mutex를 통한 중복 실행 방지
# ==========================================
_single_instance_mutex = None

def check_single_instance():
    global _single_instance_mutex
    mutex_name = "Global\\QCReportApp_v260929_SingleInstanceMutex"
    ERROR_ALREADY_EXISTS = 183
    
    _single_instance_mutex = ctypes.windll.kernel32.CreateMutexW(None, False, mutex_name)
    last_error = ctypes.windll.kernel32.GetLastError()
    
    if last_error == ERROR_ALREADY_EXISTS:
        root_temp = tk.Tk()
        root_temp.withdraw()
        messagebox.showwarning("실행 제한", "프로그램이 이미 실행 중입니다.\n기존에 실행된 프로그램을 확인해 주세요.")
        root_temp.destroy()
        sys.exit(0)

if __name__ == "__main__":
    check_single_instance()

    # 1. 원격 설정 및 실사용자 매핑 목록을 먼저 완벽히 로드
    is_allowed, block_msg = verify_remote_license()
    if not is_allowed:
        root_temp = tk.Tk()
        root_temp.withdraw()
        messagebox.showerror("프로그램 실행 제한", block_msg)
        root_temp.destroy()
        sys.exit(0)

    # 2. 프로그램 실행 알림 발송 (대상파일 미노출 및 사용자/지역 깔끔하게 분리)
    send_telemetry("프로그램 실행")

    root = TkinterDnD.Tk()
    app = QCReportApp(root)
    root.mainloop()