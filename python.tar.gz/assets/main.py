import asyncio
import pygame
import random
import math
import sys
import os
import json
import re
import time

IS_WEB = sys.platform == "emscripten"
if IS_WEB:
    from platform import window
    try:
        window.onbeforeunload = None
    except Exception:
        pass
else:
    import urllib.request

pygame.init()
pygame.font.init()

BASE_W, BASE_H = 960, 540
REAL_SCREEN = pygame.display.set_mode((BASE_W, BASE_H), pygame.RESIZABLE)
pygame.display.set_caption("Global Rebound Ball Game")
CLOCK = pygame.time.Clock()
FPS = 60

COLOR_SKY = (250, 250, 250)
COLOR_GROUND = (232, 245, 233)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (230, 40, 40)
GREEN = (40, 180, 40)
BLUE = (60, 130, 240)
GRAY = (225, 225, 225)
DARK_GRAY = (110, 110, 110)
SKY_BLUE = (180, 220, 250)
ORANGE = (225, 105, 45)
YELLOW = (255, 220, 0)

FONT_FILE = "NanumGothic.ttf"
def get_font(size, bold=False):
    if os.path.exists(FONT_FILE):
        try:
            return pygame.font.Font(FONT_FILE, size)
        except Exception:
            pass
    for name in ["malgungothic", "nanumgothic", "applegothic", "arial"]:
        f = pygame.font.SysFont(name, size, bold=bold)
        if f:
            return f
    return pygame.font.SysFont(None, size, bold=bold)

FONT_RANK = get_font(12, bold=True)
FONT_SM = get_font(14, bold=True)
FONT_MD = get_font(18, bold=True)
FONT_SCORE = get_font(20, bold=True)
FONT_LG = get_font(28, bold=True)
FONT_TITLE = get_font(34, bold=True)

BALL_RADIUS = 24
MAX_LIVES = 3
MAX_BOUNCES = 8
LOCAL_FILE = "global_game_scores.json"
FINGER_OFFSET_Y = 70

SCORE_TABLE = {
    8: 10, 7: 8, 6: 6, 5: 5,
    4: 4, 3: 2, 2: 2, 1: 1, 0: 1
}

# Firebase 실시간 DB 전용 REST 엔드포인트
FIREBASE_SCORES_URL = "https://bounces-ball-db-default-rtdb.firebaseio.com/scores.json"
STORAGE_KEY = "bounces_ball_local_cache"

def sanitize_records(raw_data):
    valid = []
    if isinstance(raw_data, dict):
        for k, r in raw_data.items():
            if isinstance(r, dict):
                score = r.get("score", 0)
                name = str(r.get("name", "")).strip()
                t = r.get("t", 0)
                name = re.sub(r'[^a-zA-Z0-9_\- ]', '', name)[:12]
                if 0 < score <= 9999 and name:
                    valid.append({"name": name, "score": int(score), "t": t})
    elif isinstance(raw_data, list):
        for r in raw_data:
            if isinstance(r, dict):
                score = r.get("score", 0)
                name = str(r.get("name", "")).strip()
                t = r.get("t", 0)
                name = re.sub(r'[^a-zA-Z0-9_\- ]', '', name)[:12]
                if 0 < score <= 9999 and name:
                    valid.append({"name": name, "score": int(score), "t": t})

    # 점수 높은 순(내림차순), 동점일 경우 시간 순(오름차순) 정렬
    valid.sort(key=lambda x: (-x["score"], x.get("t", 0)))
    return valid[:10]

def load_local_scores():
    if IS_WEB:
        try:
            raw = window.localStorage.getItem(STORAGE_KEY)
            if raw:
                return sanitize_records(json.loads(str(raw)))
        except Exception:
            pass
    if os.path.exists(LOCAL_FILE):
        try:
            with open(LOCAL_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
                return sanitize_records(saved)
        except Exception:
            pass
    return []

def save_local_scores(scores):
    if IS_WEB:
        try:
            window.localStorage.setItem(STORAGE_KEY, json.dumps(scores))
        except Exception:
            pass
    try:
        with open(LOCAL_FILE, "w", encoding="utf-8") as f:
            json.dump(scores, f)
    except Exception:
        pass

async def async_fetch_scores():
    cb = int(time.time() * 1000)
    url = f"{FIREBASE_SCORES_URL}?_t={cb}"
    if IS_WEB:
        try:
            js_fetch = f"""
            (async () => {{
                try {{
                    let res = await fetch('{url}', {{ cache: 'no-store' }});
                    if (res.ok) {{
                        let data = await res.json();
                        return JSON.stringify(data);
                    }}
                }} catch (e) {{}}
                return '';
            }})()
            """
            raw = await window.eval(js_fetch)
            if raw:
                clean = sanitize_records(json.loads(raw))
                save_local_scores(clean)
                return clean
        except Exception:
            pass
    else:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=3.0) as res:
                clean = sanitize_records(json.loads(res.read().decode('utf-8')))
                save_local_scores(clean)
                return clean
        except Exception:
            pass
    return load_local_scores()

async def async_push_score(name, score, game_instance):
    payload = json.dumps({"name": name, "score": score, "t": int(time.time() * 1000)})
    
    # 로컬 즉시 반영
    curr = load_local_scores()
    curr.append({"name": name, "score": score, "t": int(time.time() * 1000)})
    game_instance.leaderboard = sanitize_records(curr)
    save_local_scores(game_instance.leaderboard)

    # Firebase 서버로 전송
    if IS_WEB:
        try:
            js_push = f"""
            (async () => {{
                try {{
                    await fetch('{FIREBASE_SCORES_URL}', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({payload})
                    }});
                }} catch (e) {{}}
            }})()
            """
            window.eval(js_push)
        except Exception:
            pass
    else:
        try:
            req = urllib.request.Request(
                FIREBASE_SCORES_URL,
                data=payload.encode('utf-8'),
                headers={'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json'},
                method='POST'
            )
            urllib.request.urlopen(req, timeout=3.0)
        except Exception:
            pass

    await asyncio.sleep(0.5)
    refreshed = await async_fetch_scores()
    if refreshed:
        game_instance.leaderboard = refreshed

def load_img(fname_base, default_draw_func, size):
    for ext in ['.svg', '.png']:
        path = fname_base + ext
        if os.path.exists(path):
            try:
                img = pygame.image.load(path).convert_alpha()
                return pygame.transform.smoothscale(img, size)
            except Exception:
                pass
    s = pygame.Surface(size, pygame.SRCALPHA)
    default_draw_func(s, size[0], size[1])
    return s

def draw_default_wood(s, w, h):
    pygame.draw.circle(s, (70, 160, 50), (w // 2, h // 2), w // 2)
    pygame.draw.circle(s, WHITE, (w // 2, h // 2), w // 2 - 2, 2)

def draw_default_soccer(s, w, h):
    pygame.draw.circle(s, WHITE, (w // 2, h // 2), w // 2)
    pygame.draw.circle(s, BLACK, (w // 2, h // 2), w // 2, 2)
    pygame.draw.polygon(s, BLACK, [(w//2, h//2 - 8), (w//2 + 8, h//2 - 2), (w//2 + 5, h//2 + 8), (w//2 - 5, h//2 + 8), (w//2 - 8, h//2 - 2)])

def draw_default_iron(s, w, h):
    pygame.draw.circle(s, (140, 45, 170), (w // 2, h // 2), w // 2)
    pygame.draw.circle(s, WHITE, (w // 2, h // 2), w // 2, 2)
    cx, cy = w // 2, h // 2
    pygame.draw.rect(s, WHITE, (cx - 5, cy - 12, 10, 24), border_radius=2)
    pygame.draw.rect(s, WHITE, (cx - 12, cy - 5, 24, 10), border_radius=2)

def draw_default_paddle(s, w, h):
    pygame.draw.arc(s, RED, (4, 3, w - 8, 48), 0, math.pi, 10)
    xs = [int(w * 0.18), int(w * 0.39), int(w * 0.61), int(w * 0.82)]
    for idx, px in enumerate(xs):
        pygame.draw.circle(s, BLACK, (px, 34), 7)
        pygame.draw.line(s, BLACK, (px, 40), (px - 8, 22), 3)
        pygame.draw.line(s, BLACK, (px + 8, 22), (px + 8, 22), 3)
        if idx in [0, 2]:
            pygame.draw.polygon(s, BLACK, [(px - 7, 70), (px + 7, 70), (px, 40)])
            pygame.draw.line(s, BLACK, (px - 3, 70), (px - 3, 100), 3)
            pygame.draw.line(s, BLACK, (px + 3, 70), (px + 3, 100), 3)
        else:
            pygame.draw.rect(s, BLACK, (px - 4, 40, 8, 30))
            pygame.draw.line(s, BLACK, (px - 2, 70), (px - 2, 100), 3)
            pygame.draw.line(s, BLACK, (px + 2, 70), (px + 2, 100), 3)

def draw_default_spark(s, w, h):
    pts = [(w*0.5, 0), (w*0.64, h*0.32), (w*0.97, h*0.14), (w*0.74, h*0.5), (w, h*0.84), (w*0.64, h*0.74), (w*0.5, h), (w*0.36, h*0.74), (0, h*0.84), (w*0.26, h*0.5), (0.03*w, h*0.14), (w*0.36, h*0.32)]
    pygame.draw.polygon(s, YELLOW, pts)
    pygame.draw.polygon(s, RED, pts, 2)

ASSETS = {
    'wood': load_img('나무공', draw_default_wood, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'soccer': load_img('축구공', draw_default_soccer, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'iron': load_img('금속공', draw_default_iron, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'paddle': load_img('튕김대', draw_default_paddle, (105, 112)),
    'spark': load_img('튕김효과', draw_default_spark, (75, 55))
}

BALL_TYPES = {
    'soccer': {'elasticity': 0.36, 'gravity': 0.15, 'spin': 0.9, 'name': '축구공', 'img': ASSETS['soccer']},
    'wood': {'elasticity': 0.30, 'gravity': 0.17, 'spin': 0.7, 'name': '나무공', 'img': ASSETS['wood']},
    'iron': {'elasticity': 0.22, 'gravity': 0.20, 'spin': 0.5, 'name': '금속공', 'img': ASSETS['iron']}
}

class Game:
    def __init__(self):
        self.leaderboard = load_local_scores()
        self.total_score = 0
        self.lives = MAX_LIVES
        
        self.paddle_area = pygame.Rect(0, BASE_H - 200, BASE_W, 200)
        self.paddle_pos = [float(BASE_W // 2), float(self.paddle_area.bottom - 55)]
        self.target_paddle_pos = list(self.paddle_pos)
        self.paddle_vel = [0.0, 0.0]
        self.paddle_history = []

        self.randomize_hoop_target()
        self.state = "START_MENU"
        self.game_msg = "화면 중앙의 [게임시작] 버튼을 터치/클릭하세요!"
        
        self.bowl_center = (38, 38)
        self.bowl_radius = 30
        self.bowl_angle = 15.0
        self.bowl_timer = 0
        
        self.all_balls = ['wood', 'soccer', 'iron']
        self.current_ball = random.choice(self.all_balls)
        self.next_ball = random.choice([b for b in self.all_balls if b != self.current_ball])
        
        self.drop_target_xs = [120, 220, 320]
        self.prev_path_idx = None
        self.current_path_idx = 0

        self.ball_pos = [float(self.bowl_center[0] + 5), float(self.bowl_center[1])]
        self.ball_prev_pos = list(self.ball_pos)
        self.ball_vel = [0.0, 0.0]
        self.ball_angle = 0.0
        self.ball_spin = 0.0

        self.spark_timer = 0
        self.spark_pos = (0, 0)
        self.bounce_count = 0
        self.bounce_cooldown = 0
        self.last_earned_score = 0

        self.player_name = ""
        self.name_registered = False
        self.input_focus = True
        self.blink_timer = 0
        self.is_submitting = False

    def randomize_hoop_target(self):
        self.board_w = 14
        self.board_margin_right = 12
        self.board_x = BASE_W - self.board_w - self.board_margin_right
        
        self.rim_w = 80
        self.rim_right = self.board_x
        self.rim_left = self.rim_right - self.rim_w
        
        min_rim_y = 120
        max_rim_y = BASE_H - 180
        self.rim_y = random.randint(min_rim_y, max_rim_y)
        self.hoop_top_y = self.rim_y - self.rim_w
        
        self.board_rect = pygame.Rect(self.board_x, self.hoop_top_y, self.board_w, BASE_H - self.hoop_top_y)
        self.net_bottom_y = self.rim_y + 65

    def start_round(self):
        self.state = "BOWL_ROTATING"
        self.bowl_angle = 15.0
        self.bowl_timer = 0
        self.bounce_count = 0
        self.bounce_cooldown = 0
        self.randomize_hoop_target()
        
        self.current_ball = self.next_ball
        self.next_ball = random.choice([b for b in self.all_balls if b != self.current_ball])

        path_candidates = [i for i in [0, 1, 2] if i != self.prev_path_idx]
        self.current_path_idx = random.choice(path_candidates)
        self.prev_path_idx = self.current_path_idx

        self.ball_pos = [float(self.bowl_center[0] + 5), float(self.bowl_center[1])]
        self.ball_prev_pos = list(self.ball_pos)
        self.ball_vel = [0.0, 0.0]
        self.ball_angle = 0.0
        self.ball_spin = 0.0
        self.game_msg = f"{self.current_path_idx + 1}번 위치로 공이 떨어집니다! 골대로 튕겨 넣으세요!"

    def handle_input(self, event, virt_mpos):
        m_pos = virt_mpos

        if self.state == "START_MENU":
            start_btn = pygame.Rect(BASE_W // 2 - 110, BASE_H // 2 - 35, 220, 70)
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if start_btn.collidepoint(m_pos):
                    self.start_round()
            return

        if self.state in ["SUCCESS_WAIT", "FAIL_WAIT"]:
            p_box = pygame.Rect(BASE_W // 2 - 150, BASE_H // 2 - 55, 300, 110)
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if p_box.collidepoint(m_pos):
                    if self.state == "FAIL_WAIT" and self.lives <= 0:
                        if self.total_score <= 0:
                            self.reset_to_start_menu()
                        else:
                            self.state = "GAME_OVER"
                            self.input_focus = True
                            self.is_submitting = False
                            pygame.key.start_text_input()
                    else:
                        self.start_round()
            return

        if self.state == "GAME_OVER":
            ibox = pygame.Rect(BASE_W // 2 - 130, 60, 260, 38)
            btn = pygame.Rect(BASE_W // 2 - 65, 108, 130, 36)

            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if ibox.collidepoint(m_pos) and not self.name_registered:
                    self.input_focus = True
                    if IS_WEB:
                        try:
                            user_input = window.prompt("Enter Name (English/Numbers only, max 12 chars):", self.player_name)
                            if user_input is not None:
                                cleaned = re.sub(r'[^a-zA-Z0-9_\- ]', '', str(user_input)).strip()
                                self.player_name = cleaned[:12]
                        except Exception:
                            pass
                    pygame.key.start_text_input()
                elif btn.collidepoint(m_pos):
                    if not self.name_registered:
                        self.submit_score()
                    else:
                        self.reset_to_start_menu()

            if event.type == pygame.TEXTINPUT and self.input_focus and not self.name_registered:
                for ch in event.text:
                    if len(self.player_name) < 12 and (ch.isalnum() or ch in " _-"):
                        self.player_name += ch

            if event.type == pygame.KEYDOWN:
                if self.name_registered and event.key in [pygame.K_RETURN, pygame.K_SPACE]:
                    self.reset_to_start_menu()
                    return
                if self.input_focus and not self.name_registered:
                    if event.key == pygame.K_RETURN:
                        self.submit_score()
                    elif event.key == pygame.K_BACKSPACE:
                        self.player_name = self.player_name[:-1]
                    elif event.key == pygame.K_SPACE:
                        if len(self.player_name) < 12:
                            self.player_name += " "
            return

        if event.type in [pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.FINGERMOTION, pygame.FINGERDOWN]:
            offset_y_pos = m_pos[1] - FINGER_OFFSET_Y
            target_x = max(50.0, min(float(m_pos[0]), float(BASE_W - 50)))
            target_y = max(float(self.paddle_area.top + 25), min(float(offset_y_pos), float(BASE_H - 45)))
            
            self.target_paddle_pos = [target_x, target_y]
            now = pygame.time.get_ticks()
            self.paddle_history.append((now, list(self.target_paddle_pos)))

    def reset_to_start_menu(self):
        pygame.key.stop_text_input()
        self.total_score = 0
        self.lives = MAX_LIVES
        self.name_registered = False
        self.is_submitting = False
        self.player_name = ""
        self.state = "START_MENU"
        self.game_msg = "화면 중앙의 [게임시작] 버튼을 터치/클릭하세요!"

    def submit_score(self):
        if self.player_name.strip() and not self.name_registered and not self.is_submitting:
            self.is_submitting = True
            pygame.key.stop_text_input()
            nm = self.player_name.strip()
            self.name_registered = True
            self.input_focus = False
            asyncio.create_task(async_push_score(nm, self.total_score, self))

    def check_point_bounce(self, px, py, radius=5):
        dx = self.ball_pos[0] - px
        dy = self.ball_pos[1] - py
        dist = math.hypot(dx, dy)
        min_d = BALL_RADIUS + radius
        if dist < min_d:
            if dist > 0.001:
                nx, ny = dx / dist, dy / dist
            else:
                nx, ny = -1.0, 0.0
            self.ball_pos[0] = px + nx * (min_d + 1)
            self.ball_pos[1] = py + ny * (min_d + 1)
            dot = self.ball_vel[0] * nx + self.ball_vel[1] * ny
            if dot < 0:
                self.ball_vel[0] = (self.ball_vel[0] - 2 * dot * nx) * 0.7
                self.ball_vel[1] = (self.ball_vel[1] - 2 * dot * ny) * 0.7
            return True
        return False

    def check_board_collision(self):
        rect = self.board_rect
        cx, cy = self.ball_pos[0], self.ball_pos[1]
        closest_x = max(rect.left, min(cx, rect.right))
        closest_y = max(rect.top, min(cy, rect.bottom))
        
        dx = cx - closest_x
        dy = cy - closest_y
        dist = math.hypot(dx, dy)

        if dist < BALL_RADIUS:
            overlap = BALL_RADIUS - dist
            if dist > 0.001:
                nx, ny = dx / dist, dy / dist
            else:
                to_left = abs(cx - rect.left)
                to_right = abs(cx - rect.right)
                to_top = abs(cy - rect.top)
                min_edge = min(to_left, to_right, to_top)
                if min_edge == to_left: nx, ny = -1.0, 0.0
                elif min_edge == to_right: nx, ny = 1.0, 0.0
                else: nx, ny = 0.0, -1.0
                overlap = BALL_RADIUS

            self.ball_pos[0] += nx * (overlap + 1.0)
            self.ball_pos[1] += ny * (overlap + 1.0)

            dot = self.ball_vel[0] * nx + self.ball_vel[1] * ny
            if dot < 0:
                self.ball_vel[0] = (self.ball_vel[0] - 2 * dot * nx) * 0.75
                self.ball_vel[1] = (self.ball_vel[1] - 2 * dot * ny) * 0.75

    def update(self):
        self.blink_timer = (self.blink_timer + 1) % 60
        if self.bounce_cooldown > 0: self.bounce_cooldown -= 1
        if self.spark_timer > 0: self.spark_timer -= 1

        self.paddle_pos[0] += (self.target_paddle_pos[0] - self.paddle_pos[0]) * 0.75
        self.paddle_pos[1] += (self.target_paddle_pos[1] - self.paddle_pos[1]) * 0.75

        now = pygame.time.get_ticks()
        self.paddle_history = [p for p in self.paddle_history if now - p[0] <= 100]
        if len(self.paddle_history) >= 2:
            dt = max(1, self.paddle_history[-1][0] - self.paddle_history[0][0])
            self.paddle_vel = [
                (self.paddle_history[-1][1][0] - self.paddle_history[0][1][0]) / dt * 25.0,
                (self.paddle_history[-1][1][1] - self.paddle_history[0][1][1]) / dt * 25.0
            ]
        else:
            self.paddle_vel = [0.0, 0.0]

        if self.state == "BOWL_ROTATING":
            self.bowl_timer += 1
            self.bowl_angle = 15.0 + min(1.0, self.bowl_timer / 240.0) * 75.0
            self.ball_angle += 2.0
            if self.bowl_timer >= 240:
                self.state = "BALL_FALLING"
                target_x = self.drop_target_xs[self.current_path_idx]
                target_y = BASE_H - 110
                dx = target_x - self.ball_pos[0]
                dy = max(10, target_y - self.ball_pos[1])
                cur_g = BALL_TYPES[self.current_ball]['gravity']
                t_frames = math.sqrt(2 * dy / cur_g)
                calc_vx = dx / max(1.0, t_frames)
                self.ball_vel = [calc_vx, 1.8]

        elif self.state == "BALL_FALLING":
            prop = BALL_TYPES[self.current_ball]
            self.ball_prev_pos = list(self.ball_pos)
            self.ball_vel[1] += prop['gravity']
            self.ball_pos[0] += self.ball_vel[0]
            self.ball_pos[1] += self.ball_vel[1]
            self.ball_angle += self.ball_spin

            self.check_board_collision()
            self.check_point_bounce(self.rim_left, self.rim_y)

            in_rim_x = (self.rim_left + 4 <= self.ball_pos[0] <= self.rim_right - 4)
            crossed_rim_down = (self.ball_prev_pos[1] <= self.rim_y) and (self.ball_pos[1] >= self.rim_y)

            if in_rim_x and crossed_rim_down and self.ball_vel[1] > 0:
                self.ball_vel = [0.0, 0.0]
                self.ball_pos = [float((self.rim_left + self.rim_right) // 2), float(self.rim_y + 18)]
                rem = max(0, MAX_BOUNCES - self.bounce_count)
                self.last_earned_score = SCORE_TABLE.get(rem, 1)
                self.total_score += self.last_earned_score
                self.state = "SUCCESS_WAIT"
                return
            elif in_rim_x and (self.ball_prev_pos[1] >= self.rim_y + 8) and (self.ball_pos[1] <= self.rim_y + 8) and self.ball_vel[1] < 0:
                self.ball_pos[1] = float(self.rim_y + 10)
                self.ball_vel[1] *= -0.6

            arc_cx = self.paddle_pos[0]
            arc_cy = self.paddle_pos[1] - 32
            arc_rx = 48.0
            arc_ry = 24.0

            dx = self.ball_pos[0] - arc_cx
            if abs(dx) <= arc_rx + BALL_RADIUS * 0.85:
                clamped_dx = max(-arc_rx + 0.1, min(arc_rx - 0.1, dx))
                surface_y = arc_cy - math.sqrt(max(0.0, 1.0 - (clamped_dx * clamped_dx) / (arc_rx * arc_rx))) * arc_ry
                hit_boundary = surface_y - BALL_RADIUS

                crossed_surface = (self.ball_prev_pos[1] <= hit_boundary + 20) and (self.ball_pos[1] >= hit_boundary - 8)
                below_arch = self.ball_pos[1] < self.paddle_pos[1] + 20

                if self.bounce_cooldown == 0 and crossed_surface and below_arch and (self.ball_vel[1] > -1.6 or self.paddle_vel[1] < -1.0):
                    if self.bounce_count >= MAX_BOUNCES:
                        self.lives -= 1
                        if self.lives <= 0 and self.total_score <= 0:
                            self.reset_to_start_menu()
                            return
                        self.state = "FAIL_WAIT"
                        self.game_msg = "튕김횟수초과"
                        return

                    self.bounce_count += 1
                    self.bounce_cooldown = 10
                    self.ball_pos[1] = hit_boundary - 1.0

                    nx = dx / (arc_rx * arc_rx)
                    ny = -abs(surface_y - arc_cy) / (arc_ry * arc_ry) if abs(surface_y - arc_cy) > 0.01 else -1.0
                    n_len = math.hypot(nx, ny)
                    if n_len > 0.001: nx /= n_len; ny /= n_len
                    else: nx, ny = 0.0, -1.0

                    dot = self.ball_vel[0] * nx + self.ball_vel[1] * ny
                    rx = self.ball_vel[0] - 2 * dot * nx
                    ry = self.ball_vel[1] - 2 * dot * ny

                    spd = max(math.hypot(rx, ry) * prop['elasticity'] * 1.35, 4.6)
                    rebound_vx = (rx / max(0.1, math.hypot(rx, ry))) * spd + (self.paddle_vel[0] * 0.55)
                    
                    # 패들 상향 스윙 보너스 속도 상한 제한 (-4.0 Clamp)
                    raw_swing_up = min(0.0, self.paddle_vel[1]) * 0.35
                    swing_up = max(-4.0, raw_swing_up)
                    
                    rebound_vy = -abs(ry) * prop['elasticity'] * 1.35 - 5.4 + swing_up

                    if rebound_vy > -7.0:
                        rebound_vy = -7.0

                    self.ball_vel = [rebound_vx, rebound_vy]
                    self.ball_spin = rebound_vx * prop['spin']

                    self.spark_timer = 10
                    self.spark_pos = (self.ball_pos[0], self.ball_pos[1] + BALL_RADIUS)

            if self.ball_pos[0] < -BALL_RADIUS or self.ball_pos[0] > BASE_W + BALL_RADIUS or self.ball_pos[1] > BASE_H + BALL_RADIUS:
                self.lives -= 1
                if self.lives <= 0 and self.total_score <= 0:
                    self.reset_to_start_menu()
                    return
                self.state = "FAIL_WAIT"
                self.game_msg = "공을 놓쳤습니다!"

    def draw_basketball_hoop(self, surface):
        pygame.draw.rect(surface, BLACK, self.board_rect)
        pygame.draw.rect(surface, (70, 70, 70), self.board_rect, 1)

        bracket_rect = pygame.Rect(self.rim_right - 4, self.rim_y - 4, 5, 14)
        pygame.draw.rect(surface, (180, 40, 30), bracket_rect)

        net_pts_top = [self.rim_left + i * ((self.rim_right - self.rim_left) / 5.0) for i in range(6)]
        bot_left = self.rim_left + 15
        bot_right = self.rim_right - 15
        net_pts_bot = [bot_left + i * ((bot_right - bot_left) / 4.0) for i in range(5)]

        for tx in net_pts_top:
            for bx in net_pts_bot:
                if abs(tx - bx) < 32:
                    pygame.draw.line(surface, (100, 100, 100), (tx, self.rim_y + 3), (bx, self.net_bottom_y), 2)
                    pygame.draw.line(surface, WHITE, (tx - 1, self.rim_y + 3), (bx - 1, self.net_bottom_y), 1)

        pygame.draw.line(surface, (120, 120, 120), (bot_left, self.net_bottom_y), (bot_right, self.net_bottom_y), 2)

        rim_rect = pygame.Rect(self.rim_left, self.rim_y - 6, self.rim_w, 15)
        pygame.draw.ellipse(surface, (230, 40, 30), rim_rect, 3)
        pygame.draw.circle(surface, (180, 20, 20), (int(self.rim_left), int(self.rim_y)), 4)
        pygame.draw.circle(surface, (180, 20, 20), (int(self.rim_right), int(self.rim_y)), 4)

    def draw(self, surface):
        surface.fill(COLOR_SKY)
        pygame.draw.rect(surface, COLOR_GROUND, self.paddle_area)

        # 상단 안내 바
        msg_bg = pygame.Rect(BASE_W // 4 - 50, 10, BASE_W // 2 + 45, 68)
        pygame.draw.rect(surface, GRAY, msg_bg, border_radius=4)
        pygame.draw.rect(surface, DARK_GRAY, msg_bg, 2, border_radius=4)
        t1 = FONT_MD.render(self.game_msg, True, BLACK)
        t2 = FONT_SM.render("규칙: 마우스/터치 이동=공 제어 | 잔여 튕김에 따라 차등 득점 (최대 10점 ~ 최소 1점)", True, (30, 80, 200))
        t3 = FONT_SM.render("적게 튕기고 농구골대를 통과할수록 높은 점수 획득! (최대 8회 초과 시 실패)", True, (120, 60, 20))
        surface.blit(t1, t1.get_rect(center=(msg_bg.centerx, msg_bg.centery - 18)))
        surface.blit(t2, t2.get_rect(center=(msg_bg.centerx, msg_bg.centery + 4)))
        surface.blit(t3, t3.get_rect(center=(msg_bg.centerx, msg_bg.centery + 21)))

        # 글로벌 TOP 10 (양식: " 등수, [점수], 이름 ")
        rank_box = pygame.Rect(BASE_W - 225, 10, 218, 235)
        pygame.draw.rect(surface, SKY_BLUE, rank_box, border_radius=6)
        pygame.draw.rect(surface, BLUE, rank_box, 2, border_radius=6)
        t_rank = FONT_MD.render("GLOBAL TOP 10", True, BLACK)
        surface.blit(t_rank, t_rank.get_rect(center=(rank_box.centerx, rank_box.y + 14)))
        
        valid_scores = [e for e in self.leaderboard if e.get("score", 0) > 0]
        for i in range(10):
            if i < len(valid_scores):
                e = valid_scores[i]
                rank_str = f"{i+1:>2}위"
                score_str = f"[{e['score']:>2}점]"
                name_str = e['name']
                txt = f"{rank_str}, {score_str}, {name_str}"
            else:
                txt = f"{i+1:>2}위"
            surface.blit(FONT_RANK.render(txt, True, BLACK), (rank_box.x + 8, rank_box.y + 30 + i * 18))

        reset_txt = FONT_RANK.render("실시간 연동(매월15일초기화)", True, (20, 60, 180))
        surface.blit(reset_txt, reset_txt.get_rect(center=(rank_box.centerx, rank_box.bottom - 12)))

        score_panel = pygame.Rect(BASE_W // 4 - 50, 84, 400, 38)
        pygame.draw.rect(surface, WHITE, score_panel, border_radius=6)
        pygame.draw.rect(surface, BLUE if self.lives > 1 else RED, score_panel, 2, border_radius=6)
        score_txt = FONT_SCORE.render(f"현재 점수: {self.total_score}점", True, (20, 40, 160))
        life_txt = FONT_SCORE.render(f"남은 기회: {'♥ ' * self.lives}", True, RED if self.lives == 1 else (200, 30, 30))
        surface.blit(score_txt, (score_panel.x + 14, score_panel.y + 8))
        surface.blit(life_txt, (score_panel.x + 220, score_panel.y + 8))

        self.draw_basketball_hoop(surface)

        if self.state in ["BOWL_ROTATING", "BALL_FALLING", "SUCCESS_WAIT", "FAIL_WAIT"]:
            b_img = pygame.transform.rotate(BALL_TYPES[self.current_ball]['img'], self.ball_angle)
            surface.blit(b_img, b_img.get_rect(center=self.ball_pos))

        if self.state in ["BALL_FALLING", "SUCCESS_WAIT", "FAIL_WAIT"]:
            next_img = BALL_TYPES[self.next_ball]['img']
            surface.blit(next_img, next_img.get_rect(center=self.bowl_center))

        b_surf = pygame.Surface((self.bowl_radius * 2, self.bowl_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(b_surf, BLACK, (self.bowl_radius, self.bowl_radius), self.bowl_radius)
        b_surf.fill((0, 0, 0, 0), pygame.Rect(self.bowl_radius, 0, self.bowl_radius, self.bowl_radius * 2))
        rot_bowl = pygame.transform.rotate(b_surf, -self.bowl_angle)
        surface.blit(rot_bowl, rot_bowl.get_rect(center=self.bowl_center))

        surface.blit(ASSETS['paddle'], ASSETS['paddle'].get_rect(center=(int(self.paddle_pos[0]), int(self.paddle_pos[1]))))

        rem_b = max(0, MAX_BOUNCES - self.bounce_count)
        box_h = 36
        b_box = pygame.Rect(int(self.paddle_pos[0]) - 36, int(self.paddle_pos[1]) + 50 - box_h, 72, box_h)
        pygame.draw.rect(surface, WHITE, b_box, border_radius=4)
        pygame.draw.rect(surface, ORANGE if rem_b > 2 else RED, b_box, 2, border_radius=4)
        t_bounce_title = FONT_RANK.render("남은 튕김", True, DARK_GRAY)
        t_bounce_val = FONT_SCORE.render(f"{rem_b} / {MAX_BOUNCES}", True, RED if rem_b <= 2 else BLACK)
        surface.blit(t_bounce_title, t_bounce_title.get_rect(center=(b_box.centerx, b_box.y + 9)))
        surface.blit(t_bounce_val, t_bounce_val.get_rect(center=(b_box.centerx, b_box.y + 24)))

        if self.spark_timer > 0:
            surface.blit(ASSETS['spark'], ASSETS['spark'].get_rect(center=self.spark_pos))

        if self.state == "START_MENU":
            overlay = pygame.Surface((BASE_W, BASE_H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 115))
            surface.blit(overlay, (0, 0))
            s_box = pygame.Rect(BASE_W // 2 - 110, BASE_H // 2 - 35, 220, 70)
            pygame.draw.rect(surface, (60, 145, 255), s_box, border_radius=14)
            pygame.draw.rect(surface, WHITE, s_box, 3, border_radius=14)
            st_txt = FONT_TITLE.render("게임시작", True, WHITE)
            surface.blit(st_txt, st_txt.get_rect(center=s_box.center))

        elif self.state == "SUCCESS_WAIT":
            p = pygame.Rect(BASE_W // 2 - 150, BASE_H // 2 - 55, 300, 110)
            pygame.draw.rect(surface, (255, 250, 220), p, border_radius=10)
            pygame.draw.rect(surface, (240, 180, 40), p, 3, border_radius=10)
            t_s1 = FONT_TITLE.render(f"★ 골인 성공! (+{self.last_earned_score}점) ★", True, (220, 120, 0))
            t_s2 = FONT_MD.render("이곳을 클릭하면 다음 판이 시작됩니다", True, BLACK)
            surface.blit(t_s1, t_s1.get_rect(center=(p.centerx, p.centery - 16)))
            surface.blit(t_s2, t_s2.get_rect(center=(p.centerx, p.centery + 21)))

        elif self.state == "FAIL_WAIT":
            p = pygame.Rect(BASE_W // 2 - 150, BASE_H // 2 - 55, 300, 110)
            pygame.draw.rect(surface, (255, 235, 235), p, border_radius=10)
            pygame.draw.rect(surface, RED, p, 3, border_radius=10)
            t_f1 = FONT_TITLE.render(self.game_msg, True, RED)
            t_f2 = FONT_MD.render(f"남은 기회: {self.lives}회 (클릭하여 계속)", True, BLACK)
            surface.blit(t_f1, t_f1.get_rect(center=(p.centerx, p.centery - 16)))
            surface.blit(t_f2, t_f2.get_rect(center=(p.centerx, p.centery + 21)))

        elif self.state == "GAME_OVER":
            overlay = pygame.Surface((BASE_W, BASE_H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 185))
            surface.blit(overlay, (0, 0))

            over_txt = FONT_TITLE.render("GAME OVER", True, RED)
            surface.blit(over_txt, over_txt.get_rect(center=(BASE_W // 2, 25)))
            
            score_res = FONT_SCORE.render(f"최종 획득 점수: {self.total_score}점", True, YELLOW)
            surface.blit(score_res, score_res.get_rect(center=(BASE_W // 2, 48)))

            ibox = pygame.Rect(BASE_W // 2 - 130, 62, 260, 36)
            pygame.draw.rect(surface, WHITE, ibox, border_radius=5)
            if self.input_focus and not self.name_registered:
                pygame.draw.rect(surface, BLUE, ibox, 2, border_radius=5)

            disp_name = self.player_name if self.player_name else ("이름 입력 (영문/터치)" if not self.name_registered else "")
            name_color = BLACK if self.player_name else DARK_GRAY
            name_v = FONT_MD.render(disp_name, True, name_color)
            surface.blit(name_v, (ibox.x + 8, ibox.y + 8))

            if self.input_focus and not self.name_registered and self.blink_timer < 30:
                cx = ibox.x + 8 + (FONT_MD.render(self.player_name, True, BLACK).get_width() if self.player_name else 0) + 2
                pygame.draw.line(surface, BLACK, (cx, ibox.y + 7), (cx, ibox.y + 29), 2)

            abtn = pygame.Rect(BASE_W // 2 - 65, 108, 130, 36)
            pygame.draw.rect(surface, YELLOW if not self.name_registered else GREEN, abtn, border_radius=6)
            btn_txt = FONT_SM.render("이름 등록" if not self.name_registered else "처음부터 다시", True, BLACK if not self.name_registered else WHITE)
            surface.blit(btn_txt, btn_txt.get_rect(center=abtn.center))

            if self.name_registered:
                h_txt = FONT_SM.render("[Enter] 또는 화면을 터치하여 다시 시작하세요", True, GRAY)
                surface.blit(h_txt, h_txt.get_rect(center=(BASE_W // 2, 160)))

async def main():
    game = Game()
    running = True

    asyncio.create_task(load_initial_scores(game))

    backbuffer = pygame.Surface((BASE_W, BASE_H))

    while running:
        is_hidden = False
        if IS_WEB:
            try:
                is_hidden = bool(window.document.hidden)
            except Exception:
                pass
        else:
            is_hidden = not pygame.key.get_focused()

        if is_hidden:
            await asyncio.sleep(0.1)
            continue

        if IS_WEB:
            cur_w = int(window.innerWidth)
            cur_h = int(window.innerHeight)
        else:
            cur_w, cur_h = REAL_SCREEN.get_size()

        if REAL_SCREEN.get_size() != (cur_w, cur_h) and cur_w > 50 and cur_h > 50:
            pygame.display.set_mode((cur_w, cur_h), pygame.RESIZABLE)

        is_portrait = (cur_h > cur_w)

        if is_portrait:
            scale = min(cur_h / BASE_W, cur_w / BASE_H)
            scaled_w = int(BASE_W * scale)
            scaled_h = int(BASE_H * scale)
            
            offset_x = (cur_h - scaled_w) // 2
            offset_y = (cur_w - scaled_h) // 2

            raw_mpos = pygame.mouse.get_pos()
            rot_mx = raw_mpos[1]
            rot_my = cur_w - raw_mpos[0]
            virt_mx = (rot_mx - offset_x) / max(0.001, scale)
            virt_my = (rot_my - offset_y) / max(0.001, scale)
            virt_mpos = (virt_mx, virt_my)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                if event.type in [pygame.FINGERDOWN, pygame.FINGERMOTION]:
                    raw_fx = event.x * cur_w
                    raw_fy = event.y * cur_h
                    rot_fx = raw_fy
                    rot_fy = cur_w - raw_fx
                    v_fx = (rot_fx - offset_x) / max(0.001, scale)
                    v_fy = (rot_fy - offset_y) / max(0.001, scale)
                    game.handle_input(event, (v_fx, v_fy))
                else:
                    game.handle_input(event, virt_mpos)

            game.update()
            game.draw(backbuffer)

            rot_surf = pygame.transform.rotate(backbuffer, -90)
            final_draw = pygame.transform.scale(rot_surf, (scaled_h, scaled_w))

            REAL_SCREEN.fill((15, 15, 20))
            REAL_SCREEN.blit(final_draw, (offset_y, offset_x))

        else:
            target_w = cur_w * 0.70
            target_h = cur_h * 0.70

            scale = min(target_w / BASE_W, target_h / BASE_H)
            scaled_w = int(BASE_W * scale)
            scaled_h = int(BASE_H * scale)
            offset_x = (cur_w - scaled_w) // 2
            offset_y = (cur_h - scaled_h) // 2

            raw_mpos = pygame.mouse.get_pos()
            virt_mx = (raw_mpos[0] - offset_x) / max(0.001, scale)
            virt_my = (raw_mpos[1] - offset_y) / max(0.001, scale)
            virt_mpos = (virt_mx, virt_my)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                if event.type in [pygame.FINGERDOWN, pygame.FINGERMOTION]:
                    finger_x = event.x * cur_w
                    finger_y = event.y * cur_h
                    virt_fx = (finger_x - offset_x) / max(0.001, scale)
                    virt_fy = (finger_y - offset_y) / max(0.001, scale)
                    game.handle_input(event, (virt_fx, virt_fy))
                else:
                    game.handle_input(event, virt_mpos)

            game.update()
            game.draw(backbuffer)

            final_draw = pygame.transform.smoothscale(backbuffer, (scaled_w, scaled_h))

            REAL_SCREEN.fill((15, 15, 20))
            REAL_SCREEN.blit(final_draw, (offset_x, offset_y))

        pygame.display.flip()
        if not IS_WEB:
            CLOCK.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

async def load_initial_scores(game):
    await asyncio.sleep(0.1)
    remote = await async_fetch_scores()
    if remote:
        game.leaderboard = remote

if __name__ == "__main__":
    asyncio.run(main())