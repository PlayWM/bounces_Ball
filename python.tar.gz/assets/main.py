# [v2026.10.03.006] 60FPS 클린 프레임 유지 및 2초 뒤 투하 카운트다운 추가
import asyncio
import pygame
import random
import math
import sys
import os
import json
import re
import time

IS_WEB = sys.platform == "emscripten"
if IS_WEB:
    from platform import window
else:
    import urllib.request

pygame.init()
pygame.font.init()

BASE_W, BASE_H = 960, 540
SCREEN = pygame.display.set_mode((BASE_W, BASE_H), pygame.RESIZABLE)
pygame.display.set_caption("Global Rebound Ball Game")
CLOCK = pygame.time.Clock()
FPS = 60

COLOR_SKY = (237, 244, 249)
COLOR_GROUND = (226, 236, 229)
WHITE = (255, 255, 255)
BLACK = (45, 52, 58)
GRAY = (228, 233, 238)
DARK_GRAY = (125, 135, 145)
PASTEL_BLUE = (195, 218, 245)
PASTEL_BLUE_BORDER = (120, 160, 210)
PASTEL_GREEN = (180, 220, 195)
PASTEL_RED = (245, 165, 165)
PASTEL_YELLOW = (255, 238, 175)
PASTEL_ORANGE = (245, 190, 150)

FONT_FILE = "NanumGothic.ttf"
FONTS = {}

def init_fonts():
    global FONTS
    def make_font(size, bold=False):
        if os.path.exists(FONT_FILE):
            try:
                return pygame.font.Font(FONT_FILE, size)
            except Exception:
                pass
        for name in ["malgungothic", "nanumgothic", "applegothic", "arial"]:
            f = pygame.font.SysFont(name, size, bold=bold)
            if f:
                return f
        return pygame.font.SysFont(None, size, bold=bold)

    FONTS["RANK"] = make_font(12, bold=True)
    FONTS["SM"] = make_font(13, bold=True)
    FONTS["MD"] = make_font(17, bold=True)
    FONTS["SCORE"] = make_font(19, bold=True)
    FONTS["LG"] = make_font(26, bold=True)
    FONTS["TITLE"] = make_font(32, bold=True)
    FONTS["ICON"] = make_font(28, bold=True)
    FONTS["COUNT"] = make_font(44, bold=True)

init_fonts()

BALL_RADIUS = 24
MAX_LIVES = 3
MAX_BOUNCES = 8
FINGER_OFFSET_Y = 70
VERSION_STRING = "v2026.10.03.006"

SCORE_TABLE = {
    8: 10, 7: 8, 6: 6, 5: 5,
    4: 4, 3: 2, 2: 2, 1: 1, 0: 1
}

FIREBASE_SCORES_URL = "https://bounces-ball-db-default-rtdb.firebaseio.com/scores.json"
GLOBAL_LEADERBOARD = []

def parse_firebase_data(raw_data):
    valid = []
    if isinstance(raw_data, dict):
        for k, r in raw_data.items():
            if isinstance(r, dict):
                score = r.get("score", 0)
                name = str(r.get("name", "")).strip()
                t = r.get("t", 0)
                clean_name = re.sub(r'[^a-zA-Z0-9_\- ]', '', name)[:12]
                try:
                    s_int = int(score)
                    if 0 < s_int <= 9999 and clean_name:
                        valid.append({"name": clean_name, "score": s_int, "t": int(t)})
                except Exception:
                    pass
    elif isinstance(raw_data, list):
        for r in raw_data:
            if isinstance(r, dict):
                score = r.get("score", 0)
                name = str(r.get("name", "")).strip()
                t = r.get("t", 0)
                clean_name = re.sub(r'[^a-zA-Z0-9_\- ]', '', name)[:12]
                try:
                    s_int = int(score)
                    if 0 < s_int <= 9999 and clean_name:
                        valid.append({"name": clean_name, "score": s_int, "t": int(t)})
                except Exception:
                    pass
    valid.sort(key=lambda x: (-x["score"], x.get("t", 0)))
    return valid[:10]

async def async_fetch_scores():
    global GLOBAL_LEADERBOARD
    cb = int(time.time() * 1000)
    url = f"{FIREBASE_SCORES_URL}?_t={cb}"
    if IS_WEB:
        try:
            js_code = f"""
            (async () => {{
                try {{
                    let r = await fetch('{url}', {{ cache: 'no-store' }});
                    if (r.ok) {{
                        let d = await r.json();
                        window._latest_scores = JSON.stringify(d);
                    }}
                }} catch(e) {{}}
            }})();
            """
            window.eval(js_code)
            raw = getattr(window, "_latest_scores", None)
            if raw and str(raw) != "null":
                res = parse_firebase_data(json.loads(str(raw)))
                if res:
                    GLOBAL_LEADERBOARD = res
        except Exception:
            pass
    else:
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=2.0) as res:
                data_str = res.read().decode('utf-8')
                if data_str and data_str != "null":
                    GLOBAL_LEADERBOARD = parse_firebase_data(json.loads(data_str))
        except Exception:
            pass

def push_firebase_score(name, score):
    global GLOBAL_LEADERBOARD
    clean_name = re.sub(r'[^a-zA-Z0-9_\- ]', '', str(name)).strip()[:12]
    try:
        val_score = int(score)
    except Exception:
        return
    if not clean_name or val_score <= 0 or val_score > 9999:
        return

    payload = json.dumps({"name": clean_name, "score": val_score, "t": int(time.time() * 1000)})
    GLOBAL_LEADERBOARD.append({"name": clean_name, "score": val_score, "t": int(time.time() * 1000)})
    GLOBAL_LEADERBOARD.sort(key=lambda x: (-x["score"], x.get("t", 0)))
    GLOBAL_LEADERBOARD = GLOBAL_LEADERBOARD[:10]

    if IS_WEB:
        try:
            js_code = f"""
            fetch('{FIREBASE_SCORES_URL}', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({payload})
            }}).catch(() => {{}});
            """
            window.eval(js_code)
        except Exception:
            pass
    else:
        try:
            req = urllib.request.Request(
                FIREBASE_SCORES_URL,
                data=payload.encode('utf-8'),
                headers={'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json'},
                method='POST'
            )
            urllib.request.urlopen(req, timeout=2.0)
        except Exception:
            pass

def draw_wood_ball(s, w, h):
    cx, cy = w // 2, h // 2
    pygame.draw.circle(s, (185, 140, 95), (cx, cy), w // 2)
    pygame.draw.circle(s, (120, 80, 45), (cx, cy), w // 2, 2)
    pygame.draw.arc(s, (135, 95, 55), (cx - 16, cy - 16, 32, 32), 0.2, 3.0, 3)
    pygame.draw.arc(s, (135, 95, 55), (cx - 10, cy - 10, 20, 20), 3.2, 5.8, 3)
    pygame.draw.circle(s, (110, 70, 35), (cx, cy), 4)

def draw_soccer_ball(s, w, h):
    cx, cy = w // 2, h // 2
    pygame.draw.circle(s, (245, 245, 245), (cx, cy), w // 2)
    pygame.draw.circle(s, (50, 55, 60), (cx, cy), w // 2, 2)
    pts = []
    for i in range(5):
        ang = math.radians(i * 72 - 18)
        pts.append((cx + 8 * math.cos(ang), cy + 8 * math.sin(ang)))
    pygame.draw.polygon(s, (45, 50, 55), pts)
    for p in pts:
        pygame.draw.line(s, (70, 75, 80), (cx, cy), (cx + (p[0] - cx) * 2.3, cy + (p[1] - cy) * 2.3), 2)

def draw_iron_ball(s, w, h):
    cx, cy = w // 2, h // 2
    pygame.draw.circle(s, (155, 165, 180), (cx, cy), w // 2)
    pygame.draw.circle(s, (80, 90, 105), (cx, cy), w // 2, 2)
    pygame.draw.circle(s, (110, 120, 135), (cx, cy), 11)
    pygame.draw.circle(s, (220, 230, 240), (cx, cy), 5)
    pygame.draw.line(s, (60, 70, 85), (cx - 14, cy), (cx + 14, cy), 3)
    pygame.draw.line(s, (60, 70, 85), (cx, cy - 14), (cx, cy + 14), 3)

def draw_default_paddle(s, w, h):
    pygame.draw.arc(s, (235, 120, 115), (4, 3, w - 8, 48), 0, math.pi, 10)
    xs = [int(w * 0.18), int(w * 0.39), int(w * 0.61), int(w * 0.82)]
    for idx, px in enumerate(xs):
        pygame.draw.circle(s, (70, 75, 80), (px, 34), 7)
        pygame.draw.line(s, (70, 75, 80), (px, 40), (px - 8, 22), 3)
        pygame.draw.line(s, (70, 75, 80), (px + 8, 22), (px + 8, 22), 3)
        if idx in [0, 2]:
            pygame.draw.polygon(s, (70, 75, 80), [(px - 7, 70), (px + 7, 70), (px, 40)])
            pygame.draw.line(s, (70, 75, 80), (px - 3, 70), (px - 3, 100), 3)
            pygame.draw.line(s, (70, 75, 80), (px + 3, 70), (px + 3, 100), 3)
        else:
            pygame.draw.rect(s, (70, 75, 80), (px - 4, 40, 8, 30))
            pygame.draw.line(s, (70, 75, 80), (px - 2, 70), (px - 2, 100), 3)
            pygame.draw.line(s, (70, 75, 80), (px + 2, 70), (px + 2, 100), 3)

def draw_default_spark(s, w, h):
    pts = [(w*0.5, 0), (w*0.64, h*0.32), (w*0.97, h*0.14), (w*0.74, h*0.5), (w, h*0.84), (w*0.64, h*0.74), (w*0.5, h), (w*0.36, h*0.74), (0, h*0.84), (w*0.26, h*0.5), (0.03*w, h*0.14), (w*0.36, h*0.32)]
    pygame.draw.polygon(s, PASTEL_YELLOW, pts)
    pygame.draw.polygon(s, PASTEL_ORANGE, pts, 2)

def load_canvas_img(draw_func, size):
    s = pygame.Surface(size, pygame.SRCALPHA)
    draw_func(s, size[0], size[1])
    return s

RAW_ASSETS = {
    'wood': load_canvas_img(draw_wood_ball, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'soccer': load_canvas_img(draw_soccer_ball, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'iron': load_canvas_img(draw_iron_ball, (BALL_RADIUS * 2, BALL_RADIUS * 2)),
    'paddle': load_canvas_img(draw_default_paddle, (105, 112)),
    'spark': load_canvas_img(draw_default_spark, (75, 55))
}

ROT_CACHE = {'wood': {}, 'soccer': {}, 'iron': {}}
for b_key in ['wood', 'soccer', 'iron']:
    for deg in range(0, 360, 2):
        ROT_CACHE[b_key][deg] = pygame.transform.rotate(RAW_ASSETS[b_key], deg)

def get_rotated_ball(ball_type, angle):
    norm_deg = int(angle % 360)
    cached_deg = (norm_deg // 2) * 2
    return ROT_CACHE[ball_type].get(cached_deg, RAW_ASSETS[ball_type])

BALL_TYPES = {
    'iron': {
        'base_bounce_vy': -8.0,
        'elasticity': 0.50,
        'gravity': 0.28,
        'spin_rate': 0.45,
        'name': '금속공',
        'raw_img': RAW_ASSETS['iron']
    },
    'wood': {
        'base_bounce_vy': -9.6,
        'elasticity': 0.60,
        'gravity': 0.22,
        'spin_rate': 0.60,
        'name': '나무공',
        'raw_img': RAW_ASSETS['wood']
    },
    'soccer': {
        'base_bounce_vy': -11.52,
        'elasticity': 0.72,
        'gravity': 0.17,
        'spin_rate': 0.80,
        'name': '축구공',
        'raw_img': RAW_ASSETS['soccer']
    }
}

class Game:
    def __init__(self):
        self.total_score = 0
        self.lives = MAX_LIVES
        
        self.paddle_area = pygame.Rect(0, BASE_H - 200, BASE_W, 200)
        self.paddle_pos = [float(BASE_W // 2), float(self.paddle_area.bottom - 55)]
        self.prev_paddle_pos = list(self.paddle_pos)
        self.target_paddle_pos = list(self.paddle_pos)
        self.paddle_vel = [0.0, 0.0]

        self.btn_rotate = pygame.Rect(BASE_W - 108, BASE_H - 78, 100, 70)
        self.rotated = False

        self.randomize_hoop_target()
        self.state = "START_MENU"
        self.game_msg = "골대를 향해 공을 튕겨 넣으세요!"
        
        self.bowl_center = (42, 42)
        self.bowl_radius = 32
        self.bowl_timer = 0
        self.countdown_val = None
        
        self.all_balls = ['iron', 'wood', 'soccer']
        self.current_ball = random.choice(self.all_balls)
        self.next_ball = random.choice([b for b in self.all_balls if b != self.current_ball])
        
        self.drop_target_xs = [120, 220, 320]
        self.prev_path_idx = None
        self.current_path_idx = 0

        self.ball_pos = [float(self.bowl_center[0]), float(self.bowl_center[1])]
        self.ball_prev_pos = list(self.ball_pos)
        self.ball_vel = [0.0, 0.0]
        self.ball_angle = 0.0
        self.ball_spin = 0.0

        self.spark_timer = 0
        self.spark_pos = (0, 0)
        self.bounce_count = 0
        self.bounce_cooldown = 0
        self.last_earned_score = 0

        self.player_name = ""
        self.name_registered = False
        self.input_focus = True
        self.blink_timer = 0
        self.is_submitting = False

    def randomize_hoop_target(self):
        self.board_w = 14
        self.board_margin_right = 12
        self.board_x = BASE_W - self.board_w - self.board_margin_right
        
        self.rim_w = 80
        self.rim_right = self.board_x
        self.rim_left = self.rim_right - self.rim_w
        
        min_rim_y = 120
        max_rim_y = BASE_H - 180
        self.rim_y = random.randint(min_rim_y, max_rim_y)
        self.hoop_top_y = self.rim_y - self.rim_w
        
        self.board_rect = pygame.Rect(self.board_x, self.hoop_top_y, self.board_w, BASE_H - self.hoop_top_y)
        self.net_bottom_y = self.rim_y + 65

    def start_round(self):
        self.state = "BOWL_ROTATING"
        self.bowl_timer = 0
        self.countdown_val = None
        self.bounce_count = 0
        self.bounce_cooldown = 0
        self.randomize_hoop_target()
        
        self.current_ball = self.next_ball
        self.next_ball = random.choice([b for b in self.all_balls if b != self.current_ball])

        path_candidates = [i for i in [0, 1, 2] if i != self.prev_path_idx]
        self.current_path_idx = random.choice(path_candidates)
        self.prev_path_idx = self.current_path_idx

        self.ball_pos = [float(self.bowl_center[0]), float(self.bowl_center[1])]
        self.ball_prev_pos = list(self.ball_pos)
        self.ball_vel = [0.0, 0.0]
        self.ball_angle = 0.0
        self.ball_spin = 0.0
        self.game_msg = "골대를 향해 공을 튕겨 넣으세요!"

    def handle_input(self, event, m_pos):
        if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
            if self.btn_rotate.collidepoint(m_pos):
                self.rotated = not self.rotated
                return

        if self.state == "START_MENU":
            start_btn = pygame.Rect(BASE_W // 2 - 110, BASE_H // 2 - 35, 220, 70)
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if start_btn.collidepoint(m_pos):
                    self.start_round()
            return

        if self.state in ["SUCCESS_WAIT", "FAIL_WAIT"]:
            p_box = pygame.Rect(BASE_W // 2 - 150, BASE_H // 2 - 55, 300, 110)
            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if p_box.collidepoint(m_pos):
                    if self.state == "FAIL_WAIT" and self.lives <= 0:
                        if self.total_score <= 0:
                            self.reset_to_start_menu()
                        else:
                            self.state = "GAME_OVER"
                            self.input_focus = True
                            self.is_submitting = False
                            pygame.key.start_text_input()
                    else:
                        self.start_round()
            return

        if self.state == "GAME_OVER":
            ibox = pygame.Rect(BASE_W // 2 - 130, 60, 260, 38)
            btn = pygame.Rect(BASE_W // 2 - 65, 108, 130, 36)

            if (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1) or event.type == pygame.FINGERDOWN:
                if ibox.collidepoint(m_pos) and not self.name_registered:
                    self.input_focus = True
                    if IS_WEB:
                        try:
                            user_input = window.prompt("Enter Name (English/Numbers only, max 12 chars):", self.player_name)
                            if user_input is not None:
                                cleaned = re.sub(r'[^a-zA-Z0-9_\- ]', '', str(user_input)).strip()
                                self.player_name = cleaned[:12]
                        except Exception:
                            pass
                    pygame.key.start_text_input()
                elif btn.collidepoint(m_pos):
                    if not self.name_registered:
                        self.submit_score()
                    else:
                        self.reset_to_start_menu()

            if event.type == pygame.TEXTINPUT and self.input_focus and not self.name_registered:
                for ch in event.text:
                    if len(self.player_name) < 12 and (ch.isalnum() or ch in " _-"):
                        self.player_name += ch

            if event.type == pygame.KEYDOWN:
                if self.name_registered and event.key in [pygame.K_RETURN, pygame.K_SPACE]:
                    self.reset_to_start_menu()
                    return
                if self.input_focus and not self.name_registered:
                    if event.key == pygame.K_RETURN:
                        self.submit_score()
                    elif event.key == pygame.K_BACKSPACE:
                        self.player_name = self.player_name[:-1]
                    elif event.key == pygame.K_SPACE:
                        if len(self.player_name) < 12:
                            self.player_name += " "
            return

        if event.type in [pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.FINGERMOTION, pygame.FINGERDOWN]:
            offset_y_pos = m_pos[1] - FINGER_OFFSET_Y
            target_x = max(50.0, min(float(m_pos[0]), float(BASE_W - 50)))
            target_y = max(float(self.paddle_area.top + 25), min(float(offset_y_pos), float(BASE_H - 45)))
            self.target_paddle_pos = [target_x, target_y]

    def reset_to_start_menu(self):
        pygame.key.stop_text_input()
        self.total_score = 0
        self.lives = MAX_LIVES
        self.name_registered = False
        self.is_submitting = False
        self.player_name = ""
        self.state = "START_MENU"
        self.game_msg = "화면 중앙의 [게임시작] 버튼을 터치/클릭하세요!"

    def submit_score(self):
        if self.player_name.strip() and not self.name_registered and not self.is_submitting:
            self.is_submitting = True
            pygame.key.stop_text_input()
            nm = self.player_name.strip()
            self.name_registered = True
            self.input_focus = False
            push_firebase_score(nm, self.total_score)

    def check_point_bounce(self, px, py, radius=5):
        dx = self.ball_pos[0] - px
        dy = self.ball_pos[1] - py
        dist = math.hypot(dx, dy)
        min_d = BALL_RADIUS + radius
        if dist < min_d:
            if dist > 0.001:
                nx, ny = dx / dist, dy / dist
            else:
                nx, ny = -1.0, 0.0
            self.ball_pos[0] = px + nx * (min_d + 1)
            self.ball_pos[1] = py + ny * (min_d + 1)
            dot = self.ball_vel[0] * nx + self.ball_vel[1] * ny
            if dot < 0:
                self.ball_vel[0] = (self.ball_vel[0] - 2 * dot * nx) * 0.65
                self.ball_vel[1] = (self.ball_vel[1] - 2 * dot * ny) * 0.65
            return True
        return False

    def check_board_collision(self):
        rect = self.board_rect
        cx, cy = self.ball_pos[0], self.ball_pos[1]
        closest_x = max(rect.left, min(cx, rect.right))
        closest_y = max(rect.top, min(cy, rect.bottom))
        
        dx = cx - closest_x
        dy = cy - closest_y
        dist = math.hypot(dx, dy)

        if dist < BALL_RADIUS:
            overlap = BALL_RADIUS - dist
            if dist > 0.001:
                nx, ny = dx / dist, dy / dist
            else:
                nx, ny = -1.0, 0.0
                overlap = BALL_RADIUS

            self.ball_pos[0] += nx * (overlap + 1.0)
            self.ball_pos[1] += ny * (overlap + 1.0)

            dot = self.ball_vel[0] * nx + self.ball_vel[1] * ny
            if dot < 0:
                self.ball_vel[0] = (self.ball_vel[0] - 2 * dot * nx) * 0.70
                self.ball_vel[1] = (self.ball_vel[1] - 2 * dot * ny) * 0.70

    def update(self):
        self.blink_timer = (self.blink_timer + 1) % 60
        if self.bounce_cooldown > 0: self.bounce_cooldown -= 1
        if self.spark_timer > 0: self.spark_timer -= 1

        self.prev_paddle_pos = list(self.paddle_pos)
        self.paddle_pos[0] += (self.target_paddle_pos[0] - self.paddle_pos[0]) * 0.75
        self.paddle_pos[1] += (self.target_paddle_pos[1] - self.paddle_pos[1]) * 0.75
        self.paddle_vel = [self.paddle_pos[0] - self.prev_paddle_pos[0],
                           self.paddle_pos[1] - self.prev_paddle_pos[1]]

        if self.state == "BOWL_ROTATING":
            self.bowl_timer += 1
            self.ball_angle += 20.0 / 60.0
            self.ball_pos = [float(self.bowl_center[0]), float(self.bowl_center[1])]

            # 2초(120프레임) 경과 후부터 180프레임(3초) 투하 직전까지 카운트다운 계산
            if self.bowl_timer >= 120:
                frames_left = 180 - self.bowl_timer
                self.countdown_val = max(1, math.ceil(frames_left / 20.0))  # 3, 2, 1
            else:
                self.countdown_val = None

            if self.bowl_timer >= 180:
                self.countdown_val = None
                self.state = "BALL_FALLING"
                target_x = self.drop_target_xs[self.current_path_idx]
                target_y = BASE_H - 110
                dx = target_x - self.ball_pos[0]
                dy = max(10, target_y - self.ball_pos[1])
                cur_g = BALL_TYPES[self.current_ball]['gravity']
                t_frames = math.sqrt(2 * dy / cur_g)
                calc_vx = dx / max(1.0, t_frames)
                self.ball_vel = [calc_vx, 1.2]

        elif self.state == "BALL_FALLING":
            prop = BALL_TYPES[self.current_ball]
            self.ball_prev_pos = list(self.ball_pos)
            self.ball_vel[1] += prop['gravity']
            self.ball_pos[0] += self.ball_vel[0]
            self.ball_pos[1] += self.ball_vel[1]
            self.ball_angle += self.ball_spin

            self.check_board_collision()
            self.check_point_bounce(self.rim_left, self.rim_y)

            in_rim_x = (self.rim_left + 4 <= self.ball_pos[0] <= self.rim_right - 4)
            crossed_rim_down = (self.ball_prev_pos[1] <= self.rim_y) and (self.ball_pos[1] >= self.rim_y)

            if in_rim_x and crossed_rim_down and self.ball_vel[1] > 0:
                self.ball_vel = [0.0, 0.0]
                self.ball_pos = [float((self.rim_left + self.rim_right) // 2), float(self.rim_y + 18)]
                rem = max(0, MAX_BOUNCES - self.bounce_count)
                self.last_earned_score = SCORE_TABLE.get(rem, 1)
                self.total_score += self.last_earned_score
                self.state = "SUCCESS_WAIT"
                return
            elif in_rim_x and (self.ball_prev_pos[1] >= self.rim_y + 8) and (self.ball_pos[1] <= self.rim_y + 8) and self.ball_vel[1] < 0:
                self.ball_pos[1] = float(self.rim_y + 10)
                self.ball_vel[1] *= -0.5

            arc_cx = self.paddle_pos[0]
            arc_cy = self.paddle_pos[1] - 32
            arc_rx = 48.0
            arc_ry = 24.0

            dx = self.ball_pos[0] - arc_cx
            if abs(dx) <= arc_rx + BALL_RADIUS * 0.85:
                clamped_dx = max(-arc_rx + 0.1, min(arc_rx - 0.1, dx))
                surface_y = arc_cy - math.sqrt(max(0.0, 1.0 - (clamped_dx * clamped_dx) / (arc_rx * arc_rx))) * arc_ry
                hit_boundary = surface_y - BALL_RADIUS

                crossed_surface = (self.ball_prev_pos[1] <= hit_boundary + 22) and (self.ball_pos[1] >= hit_boundary - 10)
                below_arch = self.ball_pos[1] < self.paddle_pos[1] + 20

                if self.bounce_cooldown == 0 and crossed_surface and below_arch and (self.ball_vel[1] > -1.5 or self.paddle_vel[1] < -0.5):
                    if self.bounce_count >= MAX_BOUNCES:
                        self.lives -= 1
                        if self.lives <= 0 and self.total_score <= 0:
                            self.reset_to_start_menu()
                            return
                        self.state = "FAIL_WAIT"
                        self.game_msg = "튕김횟수초과"
                        return

                    self.bounce_count += 1
                    self.bounce_cooldown = 12
                    self.ball_pos[1] = hit_boundary - 2.0

                    base_vy = prop['base_bounce_vy']
                    base_vx = (dx / arc_rx) * 5.0

                    paddle_add_vx = self.paddle_vel[0] * 0.55
                    paddle_add_vy = min(0.0,프레임 제어 로직을 브라우저 표준 `requestAnimationFrame` 단일 루프로 정리하고, 리스폰 버튼 클릭 시 2초 대기 후 3·2·1 카운트다운을 표시하는 코드다.

```javascript
let countdownTimer = null;
function requestGameLoop(timestamp) {
  updatePhysics();
  render();
  requestAnimationFrame(requestGameLoop);
}
// ...