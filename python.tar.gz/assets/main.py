<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <title>Game Loop & Countdown</title>
  <style>
    body { margin: 0; overflow: hidden; background: #222; }
    canvas { display: block; width: 100vw; height: 100vh; }
    #respawnBtn {
      position: absolute; top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      padding: 12px 24px; font-size: 18px;
      display: none; cursor: pointer;
    }
    #countdown {
      position: absolute; top: 40%; left: 50%;
      transform: translate(-50%, -50%);
      font-size: 48px; color: #fff; font-weight: bold;
      display: none; pointer-events: none;
    }
  </style>
</head>
<body>
  <canvas id="gameCanvas"></canvas>
  <button id="respawnBtn">공 생성</button>
  <div id="countdown"></div>

  <script>
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const respawnBtn = document.getElementById('respawnBtn');
    const countdownEl = document.getElementById('countdown');

    function resize() {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    let ball = { x: canvas.width / 2, y: 50, vy: 0, radius: 15, active: true };
    const gravity = 0.5;

    // 1. 프레임 제어 복잡도 제거 및 60fps 기본 루프 유지
    function gameLoop() {
      if (ball.active) {
        ball.vy += gravity;
        ball.y += ball.vy;

        // 공이 화면 밖으로 이탈 시
        if (ball.y - ball.radius > canvas.height) {
          ball.active = false;
          respawnBtn.style.display = 'block';
        }
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (ball.active) {
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#ff4757';
        ctx.fill();
        ctx.closePath();
      }

      requestAnimationFrame(gameLoop);
    }

    // 2. 버튼 클릭 후 2초 대기 -> 3, 2, 1 카운트다운 후 낙하
    respawnBtn.addEventListener('click', () => {
      respawnBtn.style.display = 'none';

      // 2초 후 카운트다운 시작
      setTimeout(() => {
        let count = 3;
        countdownEl.style.display = 'block';
        countdownEl.textContent = count;

        const interval = setInterval(() => {
          count--;
          if (count > 0) {
            countdownEl.textContent = count;
          } else {
            clearInterval(interval);
            countdownEl.style.display = 'none';
            // 공 리스폰 및 낙하 시작
            ball.x = canvas.width / 2;
            ball.y = 50;
            ball.vy = 0;
            ball.active = true;
          }
        }, 1000);
      }, 2000);
    });

    requestAnimationFrame(gameLoop);
  </script>
</body>
</html>