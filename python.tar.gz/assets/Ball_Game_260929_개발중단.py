import pygame
import random
import math
import sys
import os
import threading
import json
import urllib.request

pygame.init()
pygame.font.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Global Basket Ball Game")
CLOCK = pygame.time.Clock()
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 50, 50)
GREEN = (40, 180, 40)
GRAY = (220, 220, 220)
DARK_GRAY = (100, 100, 100)
LIGHT_BLUE = (210, 230, 255)
BLUE = (50, 120, 220)
YELLOW = (255, 200, 50)

def get_font(size, bold=False):
    for f in ["malgungothic", "applegothic", "nanumgothic", "arial"]:
        font = pygame.font.SysFont(f, size, bold=bold)
        if font:
            return font
    return pygame.font.SysFont(None, size, bold=bold)

FONT_SM = get_font(15)
FONT_MD = get_font(20)
FONT_LG = get_font(28, bold=True)
FONT_TITLE = get_font(40, bold=True)

BALL_RADIUS = 20
GRAVITY = 0.45
MAX_MISSES = 3
LOCAL_FILE = "leaderboard.json"

ORIGINAL_WIDTH = SCREEN_WIDTH // 2
NEW_WIDTH = int(ORIGINAL_WIDTH * 0.7)
HAND_AREA_RECT = pygame.Rect(
    (SCREEN_WIDTH - NEW_WIDTH) // 2,
    SCREEN_HEIGHT // 2 + 50,
    NEW_WIDTH,
    SCREEN_HEIGHT - (SCREEN_HEIGHT // 2 + 70)
)
BALL_START_POS = (HAND_AREA_RECT.centerx, HAND_AREA_RECT.top + 45)

GLOBAL_API_URL = "https://api.jsonstorage.net/v1/json/00000000-0000-0000-0000-000000000000"

def fetch_global_scores():
    try:
        req = urllib.request.Request(GLOBAL_API_URL, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=2.5) as response:
            data = json.loads(response.read().decode('utf-8'))
            return sorted(data, key=lambda x: x["score"], reverse=True)[:5]
    except Exception:
        if os.path.exists(LOCAL_FILE):
            try:
                with open(LOCAL_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return [{"name": "GLOBAL", "score": 100}, {"name": "WORLD", "score": 80}]

def push_global_score(name, score):
    def _worker():
        scores = fetch_global_scores()
        scores.append({"name": name, "score": score})
        scores = sorted(scores, key=lambda x: x["score"], reverse=True)[:5]
        try:
            with open(LOCAL_FILE, "w", encoding="utf-8") as f:
                json.dump(scores, f)
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()

def create_assets():
    hand = pygame.Surface((80, 50), pygame.SRCALPHA)
    pygame.draw.ellipse(hand, (235, 195, 165), (0, 0, 80, 50))
    pygame.draw.ellipse(hand, BLACK, (0, 0, 80, 50), 2)
    ball = pygame.Surface((BALL_RADIUS * 2, BALL_RADIUS * 2), pygame.SRCALPHA)
    pygame.draw.circle(ball, BLACK, (BALL_RADIUS, BALL_RADIUS), BALL_RADIUS)
    return hand, ball

HAND_IMG, BALL_IMG = create_assets()

def draw_dashed_rect(surface, rect, color):
    dash_len, space_len = 8, 6
    for x in range(rect.left, rect.right, dash_len + space_len):
        pygame.draw.line(surface, color, (x, rect.top), (min(x + dash_len, rect.right), rect.top), 2)
        pygame.draw.line(surface, color, (x, rect.bottom), (min(x + dash_len, rect.right), rect.bottom), 2)
    for y in range(rect.top, rect.bottom, dash_len + space_len):
        pygame.draw.line(surface, color, (rect.left, y), (rect.left, min(y + dash_len, rect.bottom)), 2)
        pygame.draw.line(surface, color, (rect.right, y), (rect.right, min(y + dash_len, rect.bottom)), 2)

class Game:
    def __init__(self):
        self.leaderboard = fetch_global_scores()
        self.reset_game()

    def reset_game(self):
        self.total_score = 0
        self.misses = 0
        self.state = "PLAYING"
        self.reset_ball()
        self.generate_targets()
        self.player_name = ""
        self.name_registered = False
        self.success_timer = 0
        self.input_focus = True
        self.blink_timer = 0
        self.show_korean_popup = False
        self.popup_timer = 0

    def reset_ball(self):
        self.ball_pos = list(BALL_START_POS)
        self.ball_vel = [0, 0]
        self.is_dragging = False
        self.is_flying = False
        self.mouse_track = []
        if self.state == "WAITING_RESET":
            self.state = "PLAYING"

    def generate_targets(self):
        self.targets = [
            {'pos': [SCREEN_WIDTH * 0.25 + random.randint(-25, 25), SCREEN_HEIGHT * 0.35 + random.randint(-20, 20)], 'mult': 1.8, 'id': 1, 'score': 30},
            {'pos': [SCREEN_WIDTH * 0.50 + random.randint(-25, 25), SCREEN_HEIGHT * 0.22 + random.randint(-20, 20)], 'mult': 2.25, 'id': 2, 'score': 20},
            {'pos': [SCREEN_WIDTH * 0.75 + random.randint(-25, 25), SCREEN_HEIGHT * 0.35 + random.randint(-20, 20)], 'mult': 3.0, 'id': 3, 'score': 10}
        ]

    def handle_event(self, event):
        mouse_pos = pygame.mouse.get_pos()

        btn_reset_pos = pygame.Rect(HAND_AREA_RECT.right + 15, HAND_AREA_RECT.centery - 20, 115, 40)
        if self.state in ["WAITING_RESET", "PLAYING"] and not self.is_flying:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if btn_reset_pos.collidepoint(mouse_pos):
                    self.reset_ball()
                    return

        if self.state == "GAME_OVER":
            input_box = pygame.Rect(SCREEN_WIDTH // 2 - 90, SCREEN_HEIGHT // 2 - 5, 180, 36)
            action_btn = pygame.Rect(SCREEN_WIDTH // 2 - 60, SCREEN_HEIGHT // 2 + 80, 120, 40)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if input_box.collidepoint(mouse_pos) and not self.name_registered:
                    self.input_focus = True
                    self.blink_timer = 0
                if action_btn.collidepoint(mouse_pos):
                    if not self.name_registered:
                        self.submit_score()
                    else:
                        self.reset_game()

            if event.type == pygame.KEYDOWN and self.input_focus and not self.name_registered:
                if event.key == pygame.K_RETURN:
                    self.submit_score()
                elif event.key == pygame.K_BACKSPACE:
                    self.player_name = self.player_name[:-1]
                else:
                    ch = event.unicode
                    if ch:
                        if ('a' <= ch <= 'z') or ('A' <= ch <= 'Z'):
                            if len(self.player_name) < 10:
                                self.player_name += ch
                        else:
                            if '\uac00' <= ch <= '\ud7a3' or '\u1100' <= ch <= '\u11ff' or '\u3130' <= ch <= '\u318f':
                                self.show_korean_popup = True
                                self.popup_timer = 90
            return

        if self.state == "PLAYING" and not self.is_flying:
            ball_rect = pygame.Rect(self.ball_pos[0] - BALL_RADIUS, self.ball_pos[1] - BALL_RADIUS, BALL_RADIUS * 2, BALL_RADIUS * 2)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if ball_rect.collidepoint(mouse_pos):
                    self.is_dragging = True
                    self.mouse_track = [(pygame.time.get_ticks(), mouse_pos)]

            elif event.type == pygame.MOUSEMOTION and self.is_dragging:
                clamped_x = max(HAND_AREA_RECT.left + BALL_RADIUS, min(mouse_pos[0], HAND_AREA_RECT.right - BALL_RADIUS))
                clamped_y = max(HAND_AREA_RECT.top + BALL_RADIUS, min(mouse_pos[1], HAND_AREA_RECT.bottom - BALL_RADIUS))
                self.ball_pos = [clamped_x, clamped_y]
                self.mouse_track.append((pygame.time.get_ticks(), (clamped_x, clamped_y)))
                if len(self.mouse_track) > 10:
                    self.mouse_track.pop(0)

            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.is_dragging:
                self.is_dragging = False
                now = pygame.time.get_ticks()
                self.mouse_track = [p for p in self.mouse_track if now - p[0] <= 150]

                if len(self.mouse_track) >= 2:
                    t_start, pos_start = self.mouse_track[0]
                    t_end, pos_end = self.mouse_track[-1]
                    dt = max(1, t_end - t_start)
                    dx = pos_end[0] - pos_start[0]
                    dy = pos_end[1] - pos_start[1]

                    vx = (dx / dt) * 11.0
                    vy = (dy / dt) * 26.0

                    if vy < -3:
                        self.ball_vel = [vx, vy]
                        self.is_flying = True
                    else:
                        self.ball_pos = list(BALL_START_POS)
                else:
                    self.ball_pos = list(BALL_START_POS)

    def submit_score(self):
        if self.player_name.strip() and not self.name_registered:
            name = self.player_name.strip().upper()
            push_global_score(name, self.total_score)
            self.leaderboard.append({"name": name, "score": self.total_score})
            self.leaderboard = sorted(self.leaderboard, key=lambda x: x["score"], reverse=True)[:5]
            self.name_registered = True
            self.input_focus = False

    def update(self):
        self.blink_timer = (self.blink_timer + 1) % 60
        if self.popup_timer > 0:
            self.popup_timer -= 1
            if self.popup_timer == 0:
                self.show_korean_popup = False

        if self.success_timer > 0:
            self.success_timer -= 1

        if self.is_flying:
            self.ball_vel[1] += GRAVITY
            self.ball_pos[0] += self.ball_vel[0]
            self.ball_pos[1] += self.ball_vel[1]

            scored = False
            for target in self.targets:
                tr = BALL_RADIUS * target['mult']
                dist = math.hypot(self.ball_pos[0] - target['pos'][0], self.ball_pos[1] - target['pos'][1])
                if dist < tr * 0.8 and self.ball_vel[1] > 0:
                    self.total_score += target['score']
                    self.success_timer = 50
                    self.generate_targets()
                    self.is_flying = False
                    self.reset_ball()
                    scored = True
                    break

            if not scored:
                if (self.ball_pos[1] > SCREEN_HEIGHT + BALL_RADIUS or
                    self.ball_pos[0] < -BALL_RADIUS or self.ball_pos[0] > SCREEN_WIDTH + BALL_RADIUS):
                    self.misses += 1
                    self.is_flying = False
                    if self.misses >= MAX_MISSES:
                        self.state = "GAME_OVER"
                        self.input_focus = True
                        self.blink_timer = 0
                    else:
                        self.state = "WAITING_RESET"

    def draw(self, surface):
        surface.fill(WHITE)

        surface.blit(FONT_SM.render("★ GLOBAL RANK (TOP 5)", True, BLUE), (25, 20))
        for i, rank in enumerate(self.leaderboard):
            txt = FONT_SM.render(f"{i+1}위  {rank['name']} : {rank['score']}점", True, BLACK)
            surface.blit(txt, (25, 45 + i * 20))

        surface.blit(FONT_LG.render(f"점수: {self.total_score}", True, BLACK), (SCREEN_WIDTH - 160, 20))
        surface.blit(FONT_MD.render(f"실패: {self.misses} / {MAX_MISSES}", True, RED if self.misses > 0 else DARK_GRAY), (SCREEN_WIDTH - 160, 55))

        for t in self.targets:
            r = int(BALL_RADIUS * t['mult'])
            pos = (int(t['pos'][0]), int(t['pos'][1]))
            pygame.draw.ellipse(surface, GRAY, (pos[0] - r, pos[1] - r // 2, r * 2, r))
            pygame.draw.ellipse(surface, BLACK, (pos[0] - r, pos[1] - r // 2, r * 2, r), 3)
            num_txt = FONT_MD.render(str(t['id']), True, BLACK)
            surface.blit(num_txt, num_txt.get_rect(center=pos))

        draw_dashed_rect(surface, HAND_AREA_RECT, RED)

        if not self.is_flying:
            surface.blit(HAND_IMG, (self.ball_pos[0] - HAND_IMG.get_width() // 2, self.ball_pos[1] - 5))
        surface.blit(BALL_IMG, (self.ball_pos[0] - BALL_RADIUS, self.ball_pos[1] - BALL_RADIUS))

        if self.is_dragging:
            pygame.draw.line(surface, GREEN, BALL_START_POS, self.ball_pos, 2)

        if self.success_timer > 0:
            succ_txt = FONT_TITLE.render("성공!", True, GREEN)
            surface.blit(succ_txt, succ_txt.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 40)))

        btn_reset_pos = pygame.Rect(HAND_AREA_RECT.right + 15, HAND_AREA_RECT.centery - 20, 115, 40)
        pygame.draw.rect(surface, LIGHT_BLUE, btn_reset_pos, border_radius=6)
        pygame.draw.rect(surface, BLUE, btn_reset_pos, 2, border_radius=6)
        btn_txt = FONT_SM.render("공 위치 초기화", True, BLACK)
        surface.blit(btn_txt, btn_txt.get_rect(center=btn_reset_pos.center))

        if self.state == "GAME_OVER":
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            surface.blit(overlay, (0, 0))

            over_txt = FONT_TITLE.render("GAME OVER", True, RED)
            surface.blit(over_txt, over_txt.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 110)))

            score_txt = FONT_LG.render(f"내 점수: {self.total_score}점", True, WHITE)
            surface.blit(score_txt, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2 - 50))

            input_box = pygame.Rect(SCREEN_WIDTH // 2 - 90, SCREEN_HEIGHT // 2 - 5, 180, 36)
            pygame.draw.rect(surface, WHITE, input_box, border_radius=4)
            if self.input_focus and not self.name_registered:
                pygame.draw.rect(surface, BLUE, input_box, 2, border_radius=4)

            name_val = FONT_MD.render(self.player_name, True, BLACK)
            surface.blit(name_val, (input_box.x + 8, input_box.y + 7))

            if self.input_focus and not self.name_registered and self.blink_timer < 30:
                cursor_x = input_box.x + 8 + name_val.get_width() + 2
                pygame.draw.line(surface, BLACK, (cursor_x, input_box.y + 6), (cursor_x, input_box.y + 28), 2)

            action_btn = pygame.Rect(SCREEN_WIDTH // 2 - 60, SCREEN_HEIGHT // 2 + 80, 120, 40)
            if not self.name_registered:
                pygame.draw.rect(surface, YELLOW, action_btn, border_radius=6)
                btn_lbl = FONT_SM.render("이름등록", True, BLACK)
            else:
                pygame.draw.rect(surface, GREEN, action_btn, border_radius=6)
                btn_lbl = FONT_SM.render("다시 시작", True, WHITE)
            surface.blit(btn_lbl, btn_lbl.get_rect(center=action_btn.center))

            if self.show_korean_popup:
                popup_rect = pygame.Rect(SCREEN_WIDTH // 2 - 110, SCREEN_HEIGHT // 2 + 40, 220, 32)
                pygame.draw.rect(surface, RED, popup_rect, border_radius=5)
                warn_txt = FONT_SM.render("영문으로 변경해 주세요!", True, WHITE)
                surface.blit(warn_txt, warn_txt.get_rect(center=popup_rect.center))

def main():
    game = Game()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            game.handle_event(event)
        game.update()
        game.draw(SCREEN)
        pygame.display.flip()
        CLOCK.tick(FPS)
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()